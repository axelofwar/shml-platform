--
-- PostgreSQL database dump
--

\restrict 5HZHA68YimRR2zu4AuGTBEzhQbslAp1gTefcYlxQqUVmdh7PVxZqb9kL2niSgo9

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO mlflow;

--
-- Name: datasets; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.datasets (
    dataset_uuid character varying(36) NOT NULL,
    experiment_id integer NOT NULL,
    name character varying(500) NOT NULL,
    digest character varying(36) NOT NULL,
    dataset_source_type character varying(36) NOT NULL,
    dataset_source text NOT NULL,
    dataset_schema text,
    dataset_profile text
);


ALTER TABLE public.datasets OWNER TO mlflow;

--
-- Name: experiment_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.experiment_tags (
    key character varying(250) NOT NULL,
    value character varying(5000),
    experiment_id integer NOT NULL
);


ALTER TABLE public.experiment_tags OWNER TO mlflow;

--
-- Name: experiments; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.experiments (
    experiment_id integer NOT NULL,
    name character varying(256) NOT NULL,
    artifact_location character varying(256),
    lifecycle_stage character varying(32),
    creation_time bigint,
    last_update_time bigint,
    CONSTRAINT experiments_lifecycle_stage CHECK (((lifecycle_stage)::text = ANY ((ARRAY['active'::character varying, 'deleted'::character varying])::text[])))
);


ALTER TABLE public.experiments OWNER TO mlflow;

--
-- Name: experiments_experiment_id_seq; Type: SEQUENCE; Schema: public; Owner: mlflow
--

CREATE SEQUENCE public.experiments_experiment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.experiments_experiment_id_seq OWNER TO mlflow;

--
-- Name: experiments_experiment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mlflow
--

ALTER SEQUENCE public.experiments_experiment_id_seq OWNED BY public.experiments.experiment_id;


--
-- Name: input_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.input_tags (
    input_uuid character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(500) NOT NULL
);


ALTER TABLE public.input_tags OWNER TO mlflow;

--
-- Name: inputs; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.inputs (
    input_uuid character varying(36) NOT NULL,
    source_type character varying(36) NOT NULL,
    source_id character varying(36) NOT NULL,
    destination_type character varying(36) NOT NULL,
    destination_id character varying(36) NOT NULL
);


ALTER TABLE public.inputs OWNER TO mlflow;

--
-- Name: latest_metrics; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.latest_metrics (
    key character varying(250) NOT NULL,
    value double precision NOT NULL,
    "timestamp" bigint,
    step bigint NOT NULL,
    is_nan boolean NOT NULL,
    run_uuid character varying(32) NOT NULL
);


ALTER TABLE public.latest_metrics OWNER TO mlflow;

--
-- Name: metrics; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.metrics (
    key character varying(250) NOT NULL,
    value double precision NOT NULL,
    "timestamp" bigint NOT NULL,
    run_uuid character varying(32) NOT NULL,
    step bigint DEFAULT '0'::bigint NOT NULL,
    is_nan boolean DEFAULT false NOT NULL
);


ALTER TABLE public.metrics OWNER TO mlflow;

--
-- Name: model_version_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.model_version_tags (
    key character varying(250) NOT NULL,
    value character varying(5000),
    name character varying(256) NOT NULL,
    version integer NOT NULL
);


ALTER TABLE public.model_version_tags OWNER TO mlflow;

--
-- Name: model_versions; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.model_versions (
    name character varying(256) NOT NULL,
    version integer NOT NULL,
    creation_time bigint,
    last_updated_time bigint,
    description character varying(5000),
    user_id character varying(256),
    current_stage character varying(20),
    source character varying(500),
    run_id character varying(32),
    status character varying(20),
    status_message character varying(500),
    run_link character varying(500),
    storage_location character varying(500)
);


ALTER TABLE public.model_versions OWNER TO mlflow;

--
-- Name: params; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.params (
    key character varying(250) NOT NULL,
    value character varying(8000) NOT NULL,
    run_uuid character varying(32) NOT NULL
);


ALTER TABLE public.params OWNER TO mlflow;

--
-- Name: registered_model_aliases; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.registered_model_aliases (
    alias character varying(256) NOT NULL,
    version integer NOT NULL,
    name character varying(256) NOT NULL
);


ALTER TABLE public.registered_model_aliases OWNER TO mlflow;

--
-- Name: registered_model_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.registered_model_tags (
    key character varying(250) NOT NULL,
    value character varying(5000),
    name character varying(256) NOT NULL
);


ALTER TABLE public.registered_model_tags OWNER TO mlflow;

--
-- Name: registered_models; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.registered_models (
    name character varying(256) NOT NULL,
    creation_time bigint,
    last_updated_time bigint,
    description character varying(5000)
);


ALTER TABLE public.registered_models OWNER TO mlflow;

--
-- Name: runs; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.runs (
    run_uuid character varying(32) NOT NULL,
    name character varying(250),
    source_type character varying(20),
    source_name character varying(500),
    entry_point_name character varying(50),
    user_id character varying(256),
    status character varying(9),
    start_time bigint,
    end_time bigint,
    source_version character varying(50),
    lifecycle_stage character varying(20),
    artifact_uri character varying(200),
    experiment_id integer,
    deleted_time bigint,
    CONSTRAINT runs_lifecycle_stage CHECK (((lifecycle_stage)::text = ANY ((ARRAY['active'::character varying, 'deleted'::character varying])::text[]))),
    CONSTRAINT runs_status_check CHECK (((status)::text = ANY ((ARRAY['SCHEDULED'::character varying, 'FAILED'::character varying, 'FINISHED'::character varying, 'RUNNING'::character varying, 'KILLED'::character varying])::text[]))),
    CONSTRAINT source_type CHECK (((source_type)::text = ANY ((ARRAY['NOTEBOOK'::character varying, 'JOB'::character varying, 'LOCAL'::character varying, 'UNKNOWN'::character varying, 'PROJECT'::character varying])::text[])))
);


ALTER TABLE public.runs OWNER TO mlflow;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.tags (
    key character varying(250) NOT NULL,
    value character varying(8000),
    run_uuid character varying(32) NOT NULL
);


ALTER TABLE public.tags OWNER TO mlflow;

--
-- Name: trace_info; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.trace_info (
    request_id character varying(50) NOT NULL,
    experiment_id integer NOT NULL,
    timestamp_ms bigint NOT NULL,
    execution_time_ms bigint,
    status character varying(50) NOT NULL
);


ALTER TABLE public.trace_info OWNER TO mlflow;

--
-- Name: trace_request_metadata; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.trace_request_metadata (
    key character varying(250) NOT NULL,
    value character varying(8000),
    request_id character varying(50) NOT NULL
);


ALTER TABLE public.trace_request_metadata OWNER TO mlflow;

--
-- Name: trace_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.trace_tags (
    key character varying(250) NOT NULL,
    value character varying(8000),
    request_id character varying(50) NOT NULL
);


ALTER TABLE public.trace_tags OWNER TO mlflow;

--
-- Name: experiments experiment_id; Type: DEFAULT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiments ALTER COLUMN experiment_id SET DEFAULT nextval('public.experiments_experiment_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.alembic_version (version_num) FROM stdin;
f5a4f2784254
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.datasets (dataset_uuid, experiment_id, name, digest, dataset_source_type, dataset_source, dataset_schema, dataset_profile) FROM stdin;
\.


--
-- Data for Name: experiment_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.experiment_tags (key, value, experiment_id) FROM stdin;
created_by	api_test	9
environment	dev	1
purpose	training	1
project	pii-pro	1
environment	staging	2
purpose	comparison	2
project	pii-pro	2
environment	benchmarking	3
purpose	performance	3
project	pii-pro	3
environment	production	4
purpose	deployment	4
project	pii-pro	4
environment	data	5
purpose	dataset-management	5
project	pii-pro	5
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.experiments (experiment_id, name, artifact_location, lifecycle_stage, creation_time, last_update_time) FROM stdin;
0	Default	/mlflow/artifacts/0	active	1763863832663	1763863832663
1	Development-Training	/mlflow/artifacts/1	active	1763866743662	1763866743662
2	Staging-Model-Comparison	/mlflow/artifacts/2	active	1763866744157	1763866744157
3	Performance-Benchmarking	/mlflow/artifacts/3	active	1763866744168	1763866744168
4	Production-Candidates	/mlflow/artifacts/4	active	1763866744177	1763866744177
5	Dataset-Registry	/mlflow/artifacts/5	active	1763866744186	1763866744186
6	test-schema-validation	/mlflow/artifacts/6	active	1763874106903	1763874106903
9	test-api-experiment	/mlflow/artifacts/test-api-experiment	active	1763875031437	1763875031437
18	test-artifact-config	/mlflow/artifacts/18	active	1763878508083	1763878508083
\.


--
-- Data for Name: input_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.input_tags (input_uuid, name, value) FROM stdin;
\.


--
-- Data for Name: inputs; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.inputs (input_uuid, source_type, source_id, destination_type, destination_id) FROM stdin;
\.


--
-- Data for Name: latest_metrics; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.latest_metrics (key, value, "timestamp", step, is_nan, run_uuid) FROM stdin;
accuracy	0.95	1763875330736	1	f	648063c29c3043b0bc791f5853b5aeb1
loss	0.05	1763875330736	1	f	648063c29c3043b0bc791f5853b5aeb1
accuracy	0.95	1763876003496	1	f	30b603bc2b47497ab5ea091302c7dd01
loss	0.05	1763876003496	1	f	30b603bc2b47497ab5ea091302c7dd01
accuracy	0.95	1763876700545	1	f	09f134341e4447c496a230ac3738fe90
loss	0.05	1763876700545	1	f	09f134341e4447c496a230ac3738fe90
accuracy	0.95	1763876774730	1	f	d42ed80f65704f4a9f762fab2e0f55d1
loss	0.05	1763876774730	1	f	d42ed80f65704f4a9f762fab2e0f55d1
accuracy	0.95	1763876862750	1	f	1fff4bff6d444ca8a9cf754f80a3f1af
loss	0.05	1763876862750	1	f	1fff4bff6d444ca8a9cf754f80a3f1af
accuracy	0.92	1763876865135	0	f	672524a0d128403290bc48faf078d51d
recall	0.96	1763876865144	0	f	672524a0d128403290bc48faf078d51d
accuracy	0.92	1763876880579	0	f	4be5da94ee7a4058a6562cac18401295
recall	0.96	1763876880593	0	f	4be5da94ee7a4058a6562cac18401295
accuracy	0.92	1763876907456	0	f	e20f375e7feb4bcfbe2d4fe7388e8a76
recall	0.96	1763876907465	0	f	e20f375e7feb4bcfbe2d4fe7388e8a76
accuracy	0.95	1763878174889	1	f	66ffaa59eb374644b43e1e6a852ba521
loss	0.05	1763878174889	1	f	66ffaa59eb374644b43e1e6a852ba521
accuracy	0.92	1763878177451	0	f	2656c44cca224bb7a824eeac013ebee7
recall	0.96	1763878177474	0	f	2656c44cca224bb7a824eeac013ebee7
accuracy	0.92	1763878299784	0	f	126bf10110d748879ee55f5f49db2fa0
recall	0.96	1763878299795	0	f	126bf10110d748879ee55f5f49db2fa0
accuracy	0.95	1763878686290	1	f	7734a6b6a8644857b7b4426f4e3c98c1
loss	0.05	1763878686290	1	f	7734a6b6a8644857b7b4426f4e3c98c1
accuracy	0.92	1763878690040	0	f	0cc425fc72c0423daf783c62eba213b2
recall	0.96	1763878690120	0	f	0cc425fc72c0423daf783c62eba213b2
accuracy	0.95	1763879001386	1	f	2c0e1cb5cf4c49fbb6d10aeca893e7f2
loss	0.05	1763879001386	1	f	2c0e1cb5cf4c49fbb6d10aeca893e7f2
accuracy	0.92	1763879006702	0	f	502dd5c855134fb3a6988473649b5664
recall	0.96	1763879006750	0	f	502dd5c855134fb3a6988473649b5664
accuracy	0.95	1763879044915	1	f	2ba330ec13d74c28a7c20bbc9ebd3f36
loss	0.05	1763879044915	1	f	2ba330ec13d74c28a7c20bbc9ebd3f36
accuracy	0.92	1763879049125	0	f	dbd9e5cf1b2d4c73bbd83b15f7912b64
recall	0.96	1763879049149	0	f	dbd9e5cf1b2d4c73bbd83b15f7912b64
accuracy	0.95	1763879058358	1	f	b3fdaa98273c42a3af405bb30cfd718c
loss	0.05	1763879058358	1	f	b3fdaa98273c42a3af405bb30cfd718c
accuracy	0.92	1763879061967	0	f	20f8e1d304de4c05b0703edd00012e81
recall	0.96	1763879061977	0	f	20f8e1d304de4c05b0703edd00012e81
accuracy	0.95	1763879217815	1	f	8a4322a00f804382815b509434cb108f
loss	0.05	1763879217815	1	f	8a4322a00f804382815b509434cb108f
accuracy	0.92	1763879220137	0	f	31441990305b4cf484775e1bfd2a039c
recall	0.96	1763879220146	0	f	31441990305b4cf484775e1bfd2a039c
\.


--
-- Data for Name: metrics; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.metrics (key, value, "timestamp", run_uuid, step, is_nan) FROM stdin;
accuracy	0.95	1763875330736	648063c29c3043b0bc791f5853b5aeb1	1	f
loss	0.05	1763875330736	648063c29c3043b0bc791f5853b5aeb1	1	f
accuracy	0.95	1763876003496	30b603bc2b47497ab5ea091302c7dd01	1	f
loss	0.05	1763876003496	30b603bc2b47497ab5ea091302c7dd01	1	f
accuracy	0.95	1763876700545	09f134341e4447c496a230ac3738fe90	1	f
loss	0.05	1763876700545	09f134341e4447c496a230ac3738fe90	1	f
accuracy	0.95	1763876774730	d42ed80f65704f4a9f762fab2e0f55d1	1	f
loss	0.05	1763876774730	d42ed80f65704f4a9f762fab2e0f55d1	1	f
accuracy	0.95	1763876862750	1fff4bff6d444ca8a9cf754f80a3f1af	1	f
loss	0.05	1763876862750	1fff4bff6d444ca8a9cf754f80a3f1af	1	f
accuracy	0.92	1763876865135	672524a0d128403290bc48faf078d51d	0	f
recall	0.96	1763876865144	672524a0d128403290bc48faf078d51d	0	f
accuracy	0.92	1763876880579	4be5da94ee7a4058a6562cac18401295	0	f
recall	0.96	1763876880593	4be5da94ee7a4058a6562cac18401295	0	f
accuracy	0.92	1763876907456	e20f375e7feb4bcfbe2d4fe7388e8a76	0	f
recall	0.96	1763876907465	e20f375e7feb4bcfbe2d4fe7388e8a76	0	f
accuracy	0.95	1763878174889	66ffaa59eb374644b43e1e6a852ba521	1	f
loss	0.05	1763878174889	66ffaa59eb374644b43e1e6a852ba521	1	f
accuracy	0.92	1763878177451	2656c44cca224bb7a824eeac013ebee7	0	f
recall	0.96	1763878177474	2656c44cca224bb7a824eeac013ebee7	0	f
accuracy	0.92	1763878299784	126bf10110d748879ee55f5f49db2fa0	0	f
recall	0.96	1763878299795	126bf10110d748879ee55f5f49db2fa0	0	f
accuracy	0.95	1763878686290	7734a6b6a8644857b7b4426f4e3c98c1	1	f
loss	0.05	1763878686290	7734a6b6a8644857b7b4426f4e3c98c1	1	f
accuracy	0.92	1763878690040	0cc425fc72c0423daf783c62eba213b2	0	f
recall	0.96	1763878690120	0cc425fc72c0423daf783c62eba213b2	0	f
accuracy	0.95	1763879001386	2c0e1cb5cf4c49fbb6d10aeca893e7f2	1	f
loss	0.05	1763879001386	2c0e1cb5cf4c49fbb6d10aeca893e7f2	1	f
accuracy	0.92	1763879006702	502dd5c855134fb3a6988473649b5664	0	f
recall	0.96	1763879006750	502dd5c855134fb3a6988473649b5664	0	f
accuracy	0.95	1763879044915	2ba330ec13d74c28a7c20bbc9ebd3f36	1	f
loss	0.05	1763879044915	2ba330ec13d74c28a7c20bbc9ebd3f36	1	f
accuracy	0.92	1763879049125	dbd9e5cf1b2d4c73bbd83b15f7912b64	0	f
recall	0.96	1763879049149	dbd9e5cf1b2d4c73bbd83b15f7912b64	0	f
accuracy	0.95	1763879058358	b3fdaa98273c42a3af405bb30cfd718c	1	f
loss	0.05	1763879058358	b3fdaa98273c42a3af405bb30cfd718c	1	f
accuracy	0.92	1763879061967	20f8e1d304de4c05b0703edd00012e81	0	f
recall	0.96	1763879061977	20f8e1d304de4c05b0703edd00012e81	0	f
accuracy	0.95	1763879217815	8a4322a00f804382815b509434cb108f	1	f
loss	0.05	1763879217815	8a4322a00f804382815b509434cb108f	1	f
accuracy	0.92	1763879220137	31441990305b4cf484775e1bfd2a039c	0	f
recall	0.96	1763879220146	31441990305b4cf484775e1bfd2a039c	0	f
\.


--
-- Data for Name: model_version_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.model_version_tags (key, value, name, version) FROM stdin;
environment	test	test-model-complete-1763879049	1
model_type	classification	test-model-complete-1763879049	1
environment	test	test-model-complete-1763879062	1
model_type	classification	test-model-complete-1763879062	1
environment	test	test-model-complete-1763879220	1
model_type	classification	test-model-complete-1763879220	1
\.


--
-- Data for Name: model_versions; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.model_versions (name, version, creation_time, last_updated_time, description, user_id, current_stage, source, run_id, status, status_message, run_link, storage_location) FROM stdin;
test-model-warnings-1763879049	1	1763879049217	1763879049217	Test model for warning validation	\N	None	runs:/dbd9e5cf1b2d4c73bbd83b15f7912b64/model	dbd9e5cf1b2d4c73bbd83b15f7912b64	READY	\N		runs:/dbd9e5cf1b2d4c73bbd83b15f7912b64/model
test-model-complete-1763879049	1	1763879049266	1763879049266	Test model with full validation	\N	None	runs:/dbd9e5cf1b2d4c73bbd83b15f7912b64/model	dbd9e5cf1b2d4c73bbd83b15f7912b64	READY	\N		runs:/dbd9e5cf1b2d4c73bbd83b15f7912b64/model
test-model-warnings-1763879062	1	1763879062888	1763879062888	Test model for warning validation	\N	None	runs:/20f8e1d304de4c05b0703edd00012e81/model	20f8e1d304de4c05b0703edd00012e81	READY	\N		runs:/20f8e1d304de4c05b0703edd00012e81/model
test-model-complete-1763879062	1	1763879062926	1763879062926	Test model with full validation	\N	None	runs:/20f8e1d304de4c05b0703edd00012e81/model	20f8e1d304de4c05b0703edd00012e81	READY	\N		runs:/20f8e1d304de4c05b0703edd00012e81/model
test-model-warnings-1763879220	1	1763879220214	1763879220214	Test model for warning validation	\N	None	runs:/31441990305b4cf484775e1bfd2a039c/model	31441990305b4cf484775e1bfd2a039c	READY	\N		runs:/31441990305b4cf484775e1bfd2a039c/model
test-model-complete-1763879220	1	1763879220260	1763879220260	Test model with full validation	\N	None	runs:/31441990305b4cf484775e1bfd2a039c/model	31441990305b4cf484775e1bfd2a039c	READY	\N		runs:/31441990305b4cf484775e1bfd2a039c/model
\.


--
-- Data for Name: params; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.params (key, value, run_uuid) FROM stdin;
learning_rate	0.001	9d711bc7515c4b3f87fc290a69b48cf8
batch_size	32	9d711bc7515c4b3f87fc290a69b48cf8
test_param	1.0	f84789be558244dfa8f7f4e70ae6fb88
learning_rate	0.001	4d05835d44ff4ca8a80c9d5916e8a2c0
batch_size	32	4d05835d44ff4ca8a80c9d5916e8a2c0
test_param	1.0	3cb8c052bcd4414c912532d55d835cbf
learning_rate	0.001	d298a365f0e244b69ec5b3f0a7c73fab
batch_size	32	d298a365f0e244b69ec5b3f0a7c73fab
test_param	1.0	648063c29c3043b0bc791f5853b5aeb1
learning_rate	0.001	8781893afbbd429eb4502a7a682730ae
batch_size	32	8781893afbbd429eb4502a7a682730ae
test_param	1.0	30b603bc2b47497ab5ea091302c7dd01
learning_rate	0.001	6daa6941360243b386e949f203b07268
batch_size	32	6daa6941360243b386e949f203b07268
test_param	1.0	09f134341e4447c496a230ac3738fe90
learning_rate	0.001	31f31c39fadd4deab07bb7a8223b7926
batch_size	32	31f31c39fadd4deab07bb7a8223b7926
test_param	1.0	d42ed80f65704f4a9f762fab2e0f55d1
learning_rate	0.001	b88953635fa5443fbf8c823e6bce72de
batch_size	32	b88953635fa5443fbf8c823e6bce72de
test_param	1.0	1fff4bff6d444ca8a9cf754f80a3f1af
learning_rate	0.001	6a458ad8e536450f8423baf41fa0810a
batch_size	32	6a458ad8e536450f8423baf41fa0810a
test_param	1.0	66ffaa59eb374644b43e1e6a852ba521
learning_rate	0.001	5a90de468b214a49bb69ead710ca4dd3
batch_size	32	5a90de468b214a49bb69ead710ca4dd3
test_param	1.0	7734a6b6a8644857b7b4426f4e3c98c1
learning_rate	0.001	af5f45170fb6421c8be52d5a9badd78f
batch_size	32	af5f45170fb6421c8be52d5a9badd78f
test_param	1.0	2c0e1cb5cf4c49fbb6d10aeca893e7f2
learning_rate	0.001	3bc1622c781b4364a0d7af2e5792713a
batch_size	32	3bc1622c781b4364a0d7af2e5792713a
test_param	1.0	2ba330ec13d74c28a7c20bbc9ebd3f36
learning_rate	0.001	b1098b2af029454397b9d09e5888d264
batch_size	32	b1098b2af029454397b9d09e5888d264
test_param	1.0	b3fdaa98273c42a3af405bb30cfd718c
learning_rate	0.001	9c0f6c167f024f3782354ba3592c7317
batch_size	32	9c0f6c167f024f3782354ba3592c7317
test_param	1.0	8a4322a00f804382815b509434cb108f
\.


--
-- Data for Name: registered_model_aliases; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.registered_model_aliases (alias, version, name) FROM stdin;
\.


--
-- Data for Name: registered_model_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.registered_model_tags (key, value, name) FROM stdin;
environment	test	test-model-complete-1763879049
model_type	classification	test-model-complete-1763879049
environment	test	test-model-complete-1763879062
model_type	classification	test-model-complete-1763879062
environment	test	test-model-complete-1763879220
model_type	classification	test-model-complete-1763879220
\.


--
-- Data for Name: registered_models; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.registered_models (name, creation_time, last_updated_time, description) FROM stdin;
test-model-warnings-1763879049	1763879049203	1763879049217	Test model for warning validation
test-model-complete-1763879049	1763879049253	1763879049266	Test model with full validation
test-model-warnings-1763879062	1763879062030	1763879062888	Test model for warning validation
test-model-complete-1763879062	1763879062918	1763879062926	Test model with full validation
test-model-warnings-1763879220	1763879220203	1763879220214	Test model for warning validation
test-model-complete-1763879220	1763879220250	1763879220260	Test model with full validation
\.


--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.runs (run_uuid, name, source_type, source_name, entry_point_name, user_id, status, start_time, end_time, source_version, lifecycle_stage, artifact_uri, experiment_id, deleted_time) FROM stdin;
6b5bcd79714249a7865101bd416e7784	test-run-fixed	UNKNOWN			unknown	RUNNING	1763874349869	\N		active	/mlflow/artifacts/6/6b5bcd79714249a7865101bd416e7784/artifacts	6	\N
339b271f92574ba18505c8c3ecde056f	test-run-fixed	UNKNOWN			unknown	RUNNING	1763874362115	\N		active	/mlflow/artifacts/6/339b271f92574ba18505c8c3ecde056f/artifacts	6	\N
9d711bc7515c4b3f87fc290a69b48cf8	test-run-complete	UNKNOWN			unknown	FINISHED	1763874372308	1763874372340		active	/mlflow/artifacts/6/9d711bc7515c4b3f87fc290a69b48cf8/artifacts	6	\N
0c5f2bf86bce481c80872f0c220f3801	test-run-incomplete	UNKNOWN			unknown	RUNNING	1763874372376	\N		active	/mlflow/artifacts/6/0c5f2bf86bce481c80872f0c220f3801/artifacts	6	\N
715ee2c5cf084fdcbf686b7d297d19ee	test-run-finish	UNKNOWN			unknown	FINISHED	1763874372993	1763874373005		active	/mlflow/artifacts/6/715ee2c5cf084fdcbf686b7d297d19ee/artifacts	6	\N
f84789be558244dfa8f7f4e70ae6fb88	test-run-api	UNKNOWN			unknown	FINISHED	1763874372913	1763874374282		active	/mlflow/artifacts/6/f84789be558244dfa8f7f4e70ae6fb88/artifacts	6	\N
4d05835d44ff4ca8a80c9d5916e8a2c0	test-run-complete	UNKNOWN			unknown	FINISHED	1763875040752	1763875040798		active	/mlflow/artifacts/6/4d05835d44ff4ca8a80c9d5916e8a2c0/artifacts	6	\N
72a74314b49f43be88f1c6cfa1a791e9	test-run-incomplete	UNKNOWN			unknown	RUNNING	1763875040838	\N		active	/mlflow/artifacts/6/72a74314b49f43be88f1c6cfa1a791e9/artifacts	6	\N
bef091ff84754bf6b6f7c0c562593fa1	test-run-finish	UNKNOWN			unknown	FINISHED	1763875042769	1763875042811		active	/mlflow/artifacts/6/bef091ff84754bf6b6f7c0c562593fa1/artifacts	6	\N
3cb8c052bcd4414c912532d55d835cbf	test-run-api	UNKNOWN			unknown	FINISHED	1763875041417	1763875042825		active	/mlflow/artifacts/6/3cb8c052bcd4414c912532d55d835cbf/artifacts	6	\N
9c88cdcb290d45eabf9b123c7cfae98b	metrics-test	UNKNOWN			unknown	RUNNING	1763875059833	\N		active	/mlflow/artifacts/6/9c88cdcb290d45eabf9b123c7cfae98b/artifacts	6	\N
d298a365f0e244b69ec5b3f0a7c73fab	test-run-complete	UNKNOWN			unknown	FINISHED	1763875327348	1763875329009		active	/mlflow/artifacts/6/d298a365f0e244b69ec5b3f0a7c73fab/artifacts	6	\N
cf461b4b5b5c4fb2b97bc817bbd8cb39	test-run-incomplete	UNKNOWN			unknown	RUNNING	1763875329052	\N		active	/mlflow/artifacts/6/cf461b4b5b5c4fb2b97bc817bbd8cb39/artifacts	6	\N
08907a2ee5a74041aaf4002bac857d7d	test-run-finish	UNKNOWN			unknown	FINISHED	1763875330769	1763875330782		active	/mlflow/artifacts/6/08907a2ee5a74041aaf4002bac857d7d/artifacts	6	\N
648063c29c3043b0bc791f5853b5aeb1	test-run-api	UNKNOWN			unknown	FINISHED	1763875329641	1763875330793		active	/mlflow/artifacts/6/648063c29c3043b0bc791f5853b5aeb1/artifacts	6	\N
8781893afbbd429eb4502a7a682730ae	test-run-complete	UNKNOWN			unknown	FINISHED	1763876001221	1763876002703		active	/mlflow/artifacts/6/8781893afbbd429eb4502a7a682730ae/artifacts	6	\N
5987cb805c1c4e3d93678d117da116aa	test-run-incomplete	UNKNOWN			unknown	RUNNING	1763876002749	\N		active	/mlflow/artifacts/6/5987cb805c1c4e3d93678d117da116aa/artifacts	6	\N
7bd4a3ddd84d44a9b6586750ea2efde7	test-run-finish	UNKNOWN			unknown	FINISHED	1763876003734	1763876003924		active	/mlflow/artifacts/6/7bd4a3ddd84d44a9b6586750ea2efde7/artifacts	6	\N
30b603bc2b47497ab5ea091302c7dd01	test-run-api	UNKNOWN			unknown	FINISHED	1763876003336	1763876004012		active	/mlflow/artifacts/6/30b603bc2b47497ab5ea091302c7dd01/artifacts	6	\N
640a310ff98043ca8d51c9579a2caa37	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763876004269	1763876004374		active	/mlflow/artifacts/6/640a310ff98043ca8d51c9579a2caa37/artifacts	6	\N
9987474eed4c450eb5dcd74b333f63fc	nervous-ant-138	UNKNOWN			axelofwar	FAILED	1763876007514	1763876009435		active	/mlflow/artifacts/6/9987474eed4c450eb5dcd74b333f63fc/artifacts	6	\N
6daa6941360243b386e949f203b07268	test-run-complete	UNKNOWN			unknown	FINISHED	1763876699785	1763876699856		active	/mlflow/artifacts/6/6daa6941360243b386e949f203b07268/artifacts	6	\N
c6fa7b2469a34f8d87dea9c7507545dd	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763876699882	1763876699894		active	/mlflow/artifacts/6/c6fa7b2469a34f8d87dea9c7507545dd/artifacts	6	\N
72ce5257c69340eb802325ff10c2c536	test-run-finish	UNKNOWN			unknown	FINISHED	1763876701797	1763876701813		active	/mlflow/artifacts/6/72ce5257c69340eb802325ff10c2c536/artifacts	6	\N
09f134341e4447c496a230ac3738fe90	test-run-api	UNKNOWN			unknown	FINISHED	1763876700477	1763876701823		active	/mlflow/artifacts/6/09f134341e4447c496a230ac3738fe90/artifacts	6	\N
4852cb3816e74dffb24e0955043e7fb8	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763876701857	1763876701919		active	/mlflow/artifacts/6/4852cb3816e74dffb24e0955043e7fb8/artifacts	6	\N
d73a31a7f24242e4b3499ae1ba4df7f2	charming-mole-277	UNKNOWN			axelofwar	FAILED	1763876702468	1763876704135		active	/mlflow/artifacts/6/d73a31a7f24242e4b3499ae1ba4df7f2/artifacts	6	\N
b543155c8bf7419b822b279115c473bc	shivering-kite-229	UNKNOWN			axelofwar	FAILED	1763876749363	1763876751017		active	/mlflow/artifacts/6/b543155c8bf7419b822b279115c473bc/artifacts	6	\N
31f31c39fadd4deab07bb7a8223b7926	test-run-complete	UNKNOWN			unknown	FINISHED	1763876773584	1763876774124		active	/mlflow/artifacts/6/31f31c39fadd4deab07bb7a8223b7926/artifacts	6	\N
d62ce9be7d2143c1a40d74d1f815cad8	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763876774145	1763876774157		active	/mlflow/artifacts/6/d62ce9be7d2143c1a40d74d1f815cad8/artifacts	6	\N
3ae60b7a218d4aafb6c3f8b1f23e1c96	test-run-finish	UNKNOWN			unknown	FINISHED	1763876775539	1763876775555		active	/mlflow/artifacts/6/3ae60b7a218d4aafb6c3f8b1f23e1c96/artifacts	6	\N
d42ed80f65704f4a9f762fab2e0f55d1	test-run-api	UNKNOWN			unknown	FINISHED	1763876774667	1763876775569		active	/mlflow/artifacts/6/d42ed80f65704f4a9f762fab2e0f55d1/artifacts	6	\N
63660308160c4e858d014c9de5dcc333	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763876775600	1763876775667		active	/mlflow/artifacts/6/63660308160c4e858d014c9de5dcc333/artifacts	6	\N
ba381b7c382846f2b32e74dd2faff8dc	rumbling-lynx-203	UNKNOWN			axelofwar	FAILED	1763876776159	1763876777812		active	/mlflow/artifacts/6/ba381b7c382846f2b32e74dd2faff8dc/artifacts	6	\N
b88953635fa5443fbf8c823e6bce72de	test-run-complete	UNKNOWN			unknown	FINISHED	1763876861282	1763876861652		active	/mlflow/artifacts/6/b88953635fa5443fbf8c823e6bce72de/artifacts	6	\N
b83909dce0bd4cef9d9720d1d722a1ab	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763876861773	1763876861938		active	/mlflow/artifacts/6/b83909dce0bd4cef9d9720d1d722a1ab/artifacts	6	\N
1fff4bff6d444ca8a9cf754f80a3f1af	test-run-api	UNKNOWN			unknown	FINISHED	1763876862663	1763876862865		active	/mlflow/artifacts/6/1fff4bff6d444ca8a9cf754f80a3f1af/artifacts	6	\N
4ce24c9a6e2e497584a0ec32401f3232	test-run-finish	UNKNOWN			unknown	FINISHED	1763876862813	1763876862843		active	/mlflow/artifacts/6/4ce24c9a6e2e497584a0ec32401f3232/artifacts	6	\N
c35248946edd4c369c73e0de70160a75	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763876862905	1763876862977		active	/mlflow/artifacts/6/c35248946edd4c369c73e0de70160a75/artifacts	6	\N
672524a0d128403290bc48faf078d51d	legendary-kite-925	UNKNOWN			axelofwar	FINISHED	1763876863501	1763876865154		active	/mlflow/artifacts/6/672524a0d128403290bc48faf078d51d/artifacts	6	\N
4be5da94ee7a4058a6562cac18401295	skittish-kite-646	UNKNOWN			axelofwar	FINISHED	1763876878865	1763876880603		active	/mlflow/artifacts/6/4be5da94ee7a4058a6562cac18401295/artifacts	6	\N
e20f375e7feb4bcfbe2d4fe7388e8a76	marvelous-shrimp-748	UNKNOWN			axelofwar	FINISHED	1763876905763	1763876907474		active	/mlflow/artifacts/6/e20f375e7feb4bcfbe2d4fe7388e8a76/artifacts	6	\N
6a458ad8e536450f8423baf41fa0810a	test-run-complete	UNKNOWN			unknown	FINISHED	1763878172887	1763878174235		active	/mlflow/artifacts/6/6a458ad8e536450f8423baf41fa0810a/artifacts	6	\N
797c66058f804ab79a8b24a495651c6f	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763878174292	1763878174316		active	/mlflow/artifacts/6/797c66058f804ab79a8b24a495651c6f/artifacts	6	\N
680ee23a83bf421c972654ab4476b2b4	test-run-finish	UNKNOWN			unknown	FINISHED	1763878174928	1763878174942		active	/mlflow/artifacts/6/680ee23a83bf421c972654ab4476b2b4/artifacts	6	\N
66ffaa59eb374644b43e1e6a852ba521	test-run-api	UNKNOWN			unknown	FINISHED	1763878174844	1763878174952		active	/mlflow/artifacts/6/66ffaa59eb374644b43e1e6a852ba521/artifacts	6	\N
be4526b7c13746b0a69e61644b15bcbf	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763878174976	1763878175039		active	/mlflow/artifacts/6/be4526b7c13746b0a69e61644b15bcbf/artifacts	6	\N
2656c44cca224bb7a824eeac013ebee7	mercurial-gnat-408	UNKNOWN			axelofwar	FINISHED	1763878175563	1763878177484		active	/mlflow/artifacts/6/2656c44cca224bb7a824eeac013ebee7/artifacts	6	\N
126bf10110d748879ee55f5f49db2fa0	whimsical-mink-417	UNKNOWN			axelofwar	FINISHED	1763878298148	1763878299806		active	/mlflow/artifacts/6/126bf10110d748879ee55f5f49db2fa0/artifacts	6	\N
6dbebb83c86545749a1f659cddd0124f	skillful-snail-426	UNKNOWN				RUNNING	1763878562000	\N		active	/mlflow/artifacts/18/6dbebb83c86545749a1f659cddd0124f/artifacts	18	\N
5a90de468b214a49bb69ead710ca4dd3	test-run-complete	UNKNOWN			unknown	FINISHED	1763878682749	1763878684177		active	/mlflow/artifacts/6/5a90de468b214a49bb69ead710ca4dd3/artifacts	6	\N
09fa8a1094fd4f99b798430c8e1566dd	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763878684208	1763878684244		active	/mlflow/artifacts/6/09fa8a1094fd4f99b798430c8e1566dd/artifacts	6	\N
5676325e5319435f81b8944fb0aee554	test-run-finish	UNKNOWN			unknown	FINISHED	1763878686349	1763878686362		active	/mlflow/artifacts/6/5676325e5319435f81b8944fb0aee554/artifacts	6	\N
7734a6b6a8644857b7b4426f4e3c98c1	test-run-api	UNKNOWN			unknown	FINISHED	1763878684781	1763878686373		active	/mlflow/artifacts/6/7734a6b6a8644857b7b4426f4e3c98c1/artifacts	6	\N
a0e125ef045e4ad3ab2d773d6525b510	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763878686412	1763878686571		active	/mlflow/artifacts/6/a0e125ef045e4ad3ab2d773d6525b510/artifacts	6	\N
0cc425fc72c0423daf783c62eba213b2	burly-bat-656	UNKNOWN			axelofwar	FINISHED	1763878687303	1763878690174		active	/mlflow/artifacts/6/0cc425fc72c0423daf783c62eba213b2/artifacts	6	\N
af5f45170fb6421c8be52d5a9badd78f	test-run-complete	UNKNOWN			unknown	FINISHED	1763878998767	1763878999823		active	/mlflow/artifacts/6/af5f45170fb6421c8be52d5a9badd78f/artifacts	6	\N
b3013958ed304125af6d52f921f83e96	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763878999861	1763878999876		active	/mlflow/artifacts/6/b3013958ed304125af6d52f921f83e96/artifacts	6	\N
c61fa02a83884a91986da3e909df78c7	test-run-finish	UNKNOWN			unknown	FINISHED	1763879001432	1763879001446		active	/mlflow/artifacts/6/c61fa02a83884a91986da3e909df78c7/artifacts	6	\N
2c0e1cb5cf4c49fbb6d10aeca893e7f2	test-run-api	UNKNOWN			unknown	FINISHED	1763879000406	1763879001455		active	/mlflow/artifacts/6/2c0e1cb5cf4c49fbb6d10aeca893e7f2/artifacts	6	\N
bae41274e3c74d2494a86c275ffdb55b	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763879001483	1763879001779		active	/mlflow/artifacts/6/bae41274e3c74d2494a86c275ffdb55b/artifacts	6	\N
502dd5c855134fb3a6988473649b5664	smiling-shad-245	UNKNOWN			axelofwar	FINISHED	1763879002398	1763879006765		active	/mlflow/artifacts/6/502dd5c855134fb3a6988473649b5664/artifacts	6	\N
3bc1622c781b4364a0d7af2e5792713a	test-run-complete	UNKNOWN			unknown	FINISHED	1763879043638	1763879044253		active	/mlflow/artifacts/6/3bc1622c781b4364a0d7af2e5792713a/artifacts	6	\N
8aef31b395d6434d81efcdd3c9719c45	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763879044299	1763879044327		active	/mlflow/artifacts/6/8aef31b395d6434d81efcdd3c9719c45/artifacts	6	\N
34bd95a0ca9343b2871fdf5e485ace87	test-run-finish	UNKNOWN			unknown	FINISHED	1763879046171	1763879046182		active	/mlflow/artifacts/6/34bd95a0ca9343b2871fdf5e485ace87/artifacts	6	\N
2ba330ec13d74c28a7c20bbc9ebd3f36	test-run-api	UNKNOWN			unknown	FINISHED	1763879044859	1763879046191		active	/mlflow/artifacts/6/2ba330ec13d74c28a7c20bbc9ebd3f36/artifacts	6	\N
ecf876c9e3414f7bb8d2a7b389ec65fc	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763879046254	1763879046301		active	/mlflow/artifacts/6/ecf876c9e3414f7bb8d2a7b389ec65fc/artifacts	6	\N
dbd9e5cf1b2d4c73bbd83b15f7912b64	orderly-jay-477	UNKNOWN			axelofwar	FINISHED	1763879046789	1763879049164		active	/mlflow/artifacts/6/dbd9e5cf1b2d4c73bbd83b15f7912b64/artifacts	6	\N
b1098b2af029454397b9d09e5888d264	test-run-complete	UNKNOWN			unknown	FINISHED	1763879057344	1763879057725		active	/mlflow/artifacts/6/b1098b2af029454397b9d09e5888d264/artifacts	6	\N
8829a62a417044bb842a323a9c011827	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763879057754	1763879057765		active	/mlflow/artifacts/6/8829a62a417044bb842a323a9c011827/artifacts	6	\N
5ceddc2c239c4cb4a4622679c46e3e99	test-run-finish	UNKNOWN			unknown	FINISHED	1763879058391	1763879058402		active	/mlflow/artifacts/6/5ceddc2c239c4cb4a4622679c46e3e99/artifacts	6	\N
b3fdaa98273c42a3af405bb30cfd718c	test-run-api	UNKNOWN			unknown	FINISHED	1763879058299	1763879059698		active	/mlflow/artifacts/6/b3fdaa98273c42a3af405bb30cfd718c/artifacts	6	\N
313dc2b7a0aa4a729aa014c0ff7f00f1	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763879059775	1763879059836		active	/mlflow/artifacts/6/313dc2b7a0aa4a729aa014c0ff7f00f1/artifacts	6	\N
20f8e1d304de4c05b0703edd00012e81	unique-sow-584	UNKNOWN			axelofwar	FINISHED	1763879060339	1763879061989		active	/mlflow/artifacts/6/20f8e1d304de4c05b0703edd00012e81/artifacts	6	\N
9c0f6c167f024f3782354ba3592c7317	test-run-complete	UNKNOWN			unknown	FINISHED	1763879217100	1763879217173		active	/mlflow/artifacts/6/9c0f6c167f024f3782354ba3592c7317/artifacts	6	\N
2b14de23630f4c5d975198dcbb67762f	test-run-incomplete	UNKNOWN			unknown	FINISHED	1763879217205	1763879217218		active	/mlflow/artifacts/6/2b14de23630f4c5d975198dcbb67762f/artifacts	6	\N
9d5caef3e5514679b544ecc83fb9f34c	test-run-finish	UNKNOWN			unknown	FINISHED	1763879217846	1763879217859		active	/mlflow/artifacts/6/9d5caef3e5514679b544ecc83fb9f34c/artifacts	6	\N
8a4322a00f804382815b509434cb108f	test-run-api	UNKNOWN			unknown	FINISHED	1763879217754	1763879217871		active	/mlflow/artifacts/6/8a4322a00f804382815b509434cb108f/artifacts	6	\N
a229f5d2cc8641569016abf3f5935383	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763879217939	1763879217991		active	/mlflow/artifacts/6/a229f5d2cc8641569016abf3f5935383/artifacts	6	\N
31441990305b4cf484775e1bfd2a039c	calm-mole-822	UNKNOWN			axelofwar	FINISHED	1763879218509	1763879220156		active	/mlflow/artifacts/6/31441990305b4cf484775e1bfd2a039c/artifacts	6	\N
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.tags (key, value, run_uuid) FROM stdin;
test	true	6b5bcd79714249a7865101bd416e7784
developer	automated-test	6b5bcd79714249a7865101bd416e7784
environment	testing	6b5bcd79714249a7865101bd416e7784
mlflow.runName	test-run-fixed	6b5bcd79714249a7865101bd416e7784
test	true	339b271f92574ba18505c8c3ecde056f
developer	automated-test	339b271f92574ba18505c8c3ecde056f
environment	testing	339b271f92574ba18505c8c3ecde056f
mlflow.runName	test-run-fixed	339b271f92574ba18505c8c3ecde056f
test	true	9d711bc7515c4b3f87fc290a69b48cf8
environment	testing	9d711bc7515c4b3f87fc290a69b48cf8
developer	automated-test	9d711bc7515c4b3f87fc290a69b48cf8
mlflow.runName	test-run-complete	9d711bc7515c4b3f87fc290a69b48cf8
test	true	0c5f2bf86bce481c80872f0c220f3801
mlflow.runName	test-run-incomplete	0c5f2bf86bce481c80872f0c220f3801
test	true	f84789be558244dfa8f7f4e70ae6fb88
environment	testing	f84789be558244dfa8f7f4e70ae6fb88
developer	automated-test	f84789be558244dfa8f7f4e70ae6fb88
mlflow.runName	test-run-api	f84789be558244dfa8f7f4e70ae6fb88
test	true	715ee2c5cf084fdcbf686b7d297d19ee
environment	testing	715ee2c5cf084fdcbf686b7d297d19ee
developer	automated-test	715ee2c5cf084fdcbf686b7d297d19ee
mlflow.runName	test-run-finish	715ee2c5cf084fdcbf686b7d297d19ee
test	true	4d05835d44ff4ca8a80c9d5916e8a2c0
environment	testing	4d05835d44ff4ca8a80c9d5916e8a2c0
developer	automated-test	4d05835d44ff4ca8a80c9d5916e8a2c0
mlflow.runName	test-run-complete	4d05835d44ff4ca8a80c9d5916e8a2c0
test	true	72a74314b49f43be88f1c6cfa1a791e9
mlflow.runName	test-run-incomplete	72a74314b49f43be88f1c6cfa1a791e9
test	true	3cb8c052bcd4414c912532d55d835cbf
environment	testing	3cb8c052bcd4414c912532d55d835cbf
developer	automated-test	3cb8c052bcd4414c912532d55d835cbf
mlflow.runName	test-run-api	3cb8c052bcd4414c912532d55d835cbf
test	true	bef091ff84754bf6b6f7c0c562593fa1
environment	testing	bef091ff84754bf6b6f7c0c562593fa1
developer	automated-test	bef091ff84754bf6b6f7c0c562593fa1
mlflow.runName	test-run-finish	bef091ff84754bf6b6f7c0c562593fa1
test	true	9c88cdcb290d45eabf9b123c7cfae98b
mlflow.runName	metrics-test	9c88cdcb290d45eabf9b123c7cfae98b
test	true	d298a365f0e244b69ec5b3f0a7c73fab
environment	testing	d298a365f0e244b69ec5b3f0a7c73fab
developer	automated-test	d298a365f0e244b69ec5b3f0a7c73fab
mlflow.runName	test-run-complete	d298a365f0e244b69ec5b3f0a7c73fab
test	true	cf461b4b5b5c4fb2b97bc817bbd8cb39
mlflow.runName	test-run-incomplete	cf461b4b5b5c4fb2b97bc817bbd8cb39
test	true	648063c29c3043b0bc791f5853b5aeb1
environment	testing	648063c29c3043b0bc791f5853b5aeb1
developer	automated-test	648063c29c3043b0bc791f5853b5aeb1
mlflow.runName	test-run-api	648063c29c3043b0bc791f5853b5aeb1
test	true	08907a2ee5a74041aaf4002bac857d7d
environment	testing	08907a2ee5a74041aaf4002bac857d7d
developer	automated-test	08907a2ee5a74041aaf4002bac857d7d
mlflow.runName	test-run-finish	08907a2ee5a74041aaf4002bac857d7d
test	true	8781893afbbd429eb4502a7a682730ae
environment	testing	8781893afbbd429eb4502a7a682730ae
developer	automated-test	8781893afbbd429eb4502a7a682730ae
mlflow.runName	test-run-complete	8781893afbbd429eb4502a7a682730ae
test	true	5987cb805c1c4e3d93678d117da116aa
mlflow.runName	test-run-incomplete	5987cb805c1c4e3d93678d117da116aa
test	true	30b603bc2b47497ab5ea091302c7dd01
environment	testing	30b603bc2b47497ab5ea091302c7dd01
developer	automated-test	30b603bc2b47497ab5ea091302c7dd01
mlflow.runName	test-run-api	30b603bc2b47497ab5ea091302c7dd01
test	true	7bd4a3ddd84d44a9b6586750ea2efde7
environment	testing	7bd4a3ddd84d44a9b6586750ea2efde7
developer	automated-test	7bd4a3ddd84d44a9b6586750ea2efde7
mlflow.runName	test-run-finish	7bd4a3ddd84d44a9b6586750ea2efde7
test	true	640a310ff98043ca8d51c9579a2caa37
environment	testing	640a310ff98043ca8d51c9579a2caa37
developer	automated-test	640a310ff98043ca8d51c9579a2caa37
mlflow.runName	test-run-artifacts	640a310ff98043ca8d51c9579a2caa37
mlflow.user	axelofwar	9987474eed4c450eb5dcd74b333f63fc
mlflow.source.name	-c	9987474eed4c450eb5dcd74b333f63fc
mlflow.source.type	LOCAL	9987474eed4c450eb5dcd74b333f63fc
test	true	9987474eed4c450eb5dcd74b333f63fc
environment	testing	9987474eed4c450eb5dcd74b333f63fc
developer	automated-test	9987474eed4c450eb5dcd74b333f63fc
mlflow.runName	nervous-ant-138	9987474eed4c450eb5dcd74b333f63fc
test	true	6daa6941360243b386e949f203b07268
environment	testing	6daa6941360243b386e949f203b07268
developer	automated-test	6daa6941360243b386e949f203b07268
mlflow.runName	test-run-complete	6daa6941360243b386e949f203b07268
test	true	c6fa7b2469a34f8d87dea9c7507545dd
mlflow.runName	test-run-incomplete	c6fa7b2469a34f8d87dea9c7507545dd
test	true	09f134341e4447c496a230ac3738fe90
environment	testing	09f134341e4447c496a230ac3738fe90
developer	automated-test	09f134341e4447c496a230ac3738fe90
mlflow.runName	test-run-api	09f134341e4447c496a230ac3738fe90
test	true	72ce5257c69340eb802325ff10c2c536
environment	testing	72ce5257c69340eb802325ff10c2c536
developer	automated-test	72ce5257c69340eb802325ff10c2c536
mlflow.runName	test-run-finish	72ce5257c69340eb802325ff10c2c536
test	true	4852cb3816e74dffb24e0955043e7fb8
environment	testing	4852cb3816e74dffb24e0955043e7fb8
developer	automated-test	4852cb3816e74dffb24e0955043e7fb8
mlflow.runName	test-run-artifacts	4852cb3816e74dffb24e0955043e7fb8
mlflow.user	axelofwar	d73a31a7f24242e4b3499ae1ba4df7f2
mlflow.source.name	-c	d73a31a7f24242e4b3499ae1ba4df7f2
mlflow.source.type	LOCAL	d73a31a7f24242e4b3499ae1ba4df7f2
test	true	d73a31a7f24242e4b3499ae1ba4df7f2
environment	testing	d73a31a7f24242e4b3499ae1ba4df7f2
developer	automated-test	d73a31a7f24242e4b3499ae1ba4df7f2
mlflow.runName	charming-mole-277	d73a31a7f24242e4b3499ae1ba4df7f2
mlflow.user	axelofwar	b543155c8bf7419b822b279115c473bc
mlflow.source.name	/home/axelofwar/Desktop/Projects/tests/venv/bin/pytest	b543155c8bf7419b822b279115c473bc
mlflow.source.type	LOCAL	b543155c8bf7419b822b279115c473bc
test	true	b543155c8bf7419b822b279115c473bc
environment	testing	b543155c8bf7419b822b279115c473bc
developer	automated-test	b543155c8bf7419b822b279115c473bc
mlflow.runName	shivering-kite-229	b543155c8bf7419b822b279115c473bc
test	true	31f31c39fadd4deab07bb7a8223b7926
environment	testing	31f31c39fadd4deab07bb7a8223b7926
developer	automated-test	31f31c39fadd4deab07bb7a8223b7926
mlflow.runName	test-run-complete	31f31c39fadd4deab07bb7a8223b7926
test	true	d62ce9be7d2143c1a40d74d1f815cad8
mlflow.runName	test-run-incomplete	d62ce9be7d2143c1a40d74d1f815cad8
test	true	d42ed80f65704f4a9f762fab2e0f55d1
environment	testing	d42ed80f65704f4a9f762fab2e0f55d1
developer	automated-test	d42ed80f65704f4a9f762fab2e0f55d1
mlflow.runName	test-run-api	d42ed80f65704f4a9f762fab2e0f55d1
test	true	3ae60b7a218d4aafb6c3f8b1f23e1c96
environment	testing	3ae60b7a218d4aafb6c3f8b1f23e1c96
developer	automated-test	3ae60b7a218d4aafb6c3f8b1f23e1c96
mlflow.runName	test-run-finish	3ae60b7a218d4aafb6c3f8b1f23e1c96
test	true	63660308160c4e858d014c9de5dcc333
environment	testing	63660308160c4e858d014c9de5dcc333
developer	automated-test	63660308160c4e858d014c9de5dcc333
mlflow.runName	test-run-artifacts	63660308160c4e858d014c9de5dcc333
mlflow.user	axelofwar	ba381b7c382846f2b32e74dd2faff8dc
mlflow.source.name	-c	ba381b7c382846f2b32e74dd2faff8dc
mlflow.source.type	LOCAL	ba381b7c382846f2b32e74dd2faff8dc
test	true	ba381b7c382846f2b32e74dd2faff8dc
environment	testing	ba381b7c382846f2b32e74dd2faff8dc
developer	automated-test	ba381b7c382846f2b32e74dd2faff8dc
mlflow.runName	rumbling-lynx-203	ba381b7c382846f2b32e74dd2faff8dc
test	true	b88953635fa5443fbf8c823e6bce72de
environment	testing	b88953635fa5443fbf8c823e6bce72de
developer	automated-test	b88953635fa5443fbf8c823e6bce72de
mlflow.runName	test-run-complete	b88953635fa5443fbf8c823e6bce72de
test	true	b83909dce0bd4cef9d9720d1d722a1ab
mlflow.runName	test-run-incomplete	b83909dce0bd4cef9d9720d1d722a1ab
test	true	1fff4bff6d444ca8a9cf754f80a3f1af
environment	testing	1fff4bff6d444ca8a9cf754f80a3f1af
developer	automated-test	1fff4bff6d444ca8a9cf754f80a3f1af
mlflow.runName	test-run-api	1fff4bff6d444ca8a9cf754f80a3f1af
test	true	4ce24c9a6e2e497584a0ec32401f3232
environment	testing	4ce24c9a6e2e497584a0ec32401f3232
developer	automated-test	4ce24c9a6e2e497584a0ec32401f3232
mlflow.runName	test-run-finish	4ce24c9a6e2e497584a0ec32401f3232
test	true	c35248946edd4c369c73e0de70160a75
environment	testing	c35248946edd4c369c73e0de70160a75
developer	automated-test	c35248946edd4c369c73e0de70160a75
mlflow.runName	test-run-artifacts	c35248946edd4c369c73e0de70160a75
mlflow.user	axelofwar	672524a0d128403290bc48faf078d51d
mlflow.source.name	-c	672524a0d128403290bc48faf078d51d
mlflow.source.type	LOCAL	672524a0d128403290bc48faf078d51d
test	true	672524a0d128403290bc48faf078d51d
environment	testing	672524a0d128403290bc48faf078d51d
developer	automated-test	672524a0d128403290bc48faf078d51d
mlflow.runName	legendary-kite-925	672524a0d128403290bc48faf078d51d
mlflow.log-model.history	[{"run_id": "672524a0d128403290bc48faf078d51d", "artifact_path": "model", "utc_time_created": "2025-11-23 05:47:43.526417", "model_uuid": "c6768c52269b4f41bdfa7b2961ea7c4e", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	672524a0d128403290bc48faf078d51d
mlflow.user	axelofwar	4be5da94ee7a4058a6562cac18401295
mlflow.source.name	/home/axelofwar/Desktop/Projects/tests/venv/bin/pytest	4be5da94ee7a4058a6562cac18401295
mlflow.source.type	LOCAL	4be5da94ee7a4058a6562cac18401295
test	true	4be5da94ee7a4058a6562cac18401295
environment	testing	4be5da94ee7a4058a6562cac18401295
developer	automated-test	4be5da94ee7a4058a6562cac18401295
mlflow.runName	skittish-kite-646	4be5da94ee7a4058a6562cac18401295
mlflow.log-model.history	[{"run_id": "4be5da94ee7a4058a6562cac18401295", "artifact_path": "model", "utc_time_created": "2025-11-23 05:47:58.886963", "model_uuid": "1b70ecd6e10c474c8e90b4ae8fc0af53", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	4be5da94ee7a4058a6562cac18401295
mlflow.user	axelofwar	e20f375e7feb4bcfbe2d4fe7388e8a76
mlflow.source.name	/home/axelofwar/Desktop/Projects/tests/venv/bin/pytest	e20f375e7feb4bcfbe2d4fe7388e8a76
mlflow.source.type	LOCAL	e20f375e7feb4bcfbe2d4fe7388e8a76
test	true	e20f375e7feb4bcfbe2d4fe7388e8a76
environment	testing	e20f375e7feb4bcfbe2d4fe7388e8a76
developer	automated-test	e20f375e7feb4bcfbe2d4fe7388e8a76
mlflow.runName	marvelous-shrimp-748	e20f375e7feb4bcfbe2d4fe7388e8a76
mlflow.log-model.history	[{"run_id": "e20f375e7feb4bcfbe2d4fe7388e8a76", "artifact_path": "model", "utc_time_created": "2025-11-23 05:48:25.797594", "model_uuid": "8c77dadb79d54fdfaf508a9b6cb67eda", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	e20f375e7feb4bcfbe2d4fe7388e8a76
test	true	6a458ad8e536450f8423baf41fa0810a
environment	testing	6a458ad8e536450f8423baf41fa0810a
developer	automated-test	6a458ad8e536450f8423baf41fa0810a
mlflow.runName	test-run-complete	6a458ad8e536450f8423baf41fa0810a
test	true	797c66058f804ab79a8b24a495651c6f
mlflow.runName	test-run-incomplete	797c66058f804ab79a8b24a495651c6f
test	true	66ffaa59eb374644b43e1e6a852ba521
environment	testing	66ffaa59eb374644b43e1e6a852ba521
developer	automated-test	66ffaa59eb374644b43e1e6a852ba521
mlflow.runName	test-run-api	66ffaa59eb374644b43e1e6a852ba521
test	true	680ee23a83bf421c972654ab4476b2b4
environment	testing	680ee23a83bf421c972654ab4476b2b4
developer	automated-test	680ee23a83bf421c972654ab4476b2b4
mlflow.runName	test-run-finish	680ee23a83bf421c972654ab4476b2b4
test	true	be4526b7c13746b0a69e61644b15bcbf
environment	testing	be4526b7c13746b0a69e61644b15bcbf
developer	automated-test	be4526b7c13746b0a69e61644b15bcbf
mlflow.runName	test-run-artifacts	be4526b7c13746b0a69e61644b15bcbf
mlflow.user	axelofwar	2656c44cca224bb7a824eeac013ebee7
mlflow.source.name	-c	2656c44cca224bb7a824eeac013ebee7
mlflow.source.type	LOCAL	2656c44cca224bb7a824eeac013ebee7
test	true	2656c44cca224bb7a824eeac013ebee7
environment	testing	2656c44cca224bb7a824eeac013ebee7
developer	automated-test	2656c44cca224bb7a824eeac013ebee7
mlflow.runName	mercurial-gnat-408	2656c44cca224bb7a824eeac013ebee7
mlflow.log-model.history	[{"run_id": "2656c44cca224bb7a824eeac013ebee7", "artifact_path": "model", "utc_time_created": "2025-11-23 06:09:35.578976", "model_uuid": "71afb877f1204890a33327109e58cd3a", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	2656c44cca224bb7a824eeac013ebee7
mlflow.user	axelofwar	126bf10110d748879ee55f5f49db2fa0
mlflow.source.name	/home/axelofwar/Desktop/Projects/tests/venv/bin/pytest	126bf10110d748879ee55f5f49db2fa0
mlflow.source.type	LOCAL	126bf10110d748879ee55f5f49db2fa0
test	true	126bf10110d748879ee55f5f49db2fa0
environment	testing	126bf10110d748879ee55f5f49db2fa0
developer	automated-test	126bf10110d748879ee55f5f49db2fa0
mlflow.runName	whimsical-mink-417	126bf10110d748879ee55f5f49db2fa0
mlflow.log-model.history	[{"run_id": "126bf10110d748879ee55f5f49db2fa0", "artifact_path": "model", "utc_time_created": "2025-11-23 06:11:38.173932", "model_uuid": "2b1fc229908849428ccfdaaf6710d443", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	126bf10110d748879ee55f5f49db2fa0
test	true	6dbebb83c86545749a1f659cddd0124f
mlflow.runName	skillful-snail-426	6dbebb83c86545749a1f659cddd0124f
test	true	5a90de468b214a49bb69ead710ca4dd3
environment	testing	5a90de468b214a49bb69ead710ca4dd3
developer	automated-test	5a90de468b214a49bb69ead710ca4dd3
mlflow.runName	test-run-complete	5a90de468b214a49bb69ead710ca4dd3
test	true	09fa8a1094fd4f99b798430c8e1566dd
mlflow.runName	test-run-incomplete	09fa8a1094fd4f99b798430c8e1566dd
test	true	7734a6b6a8644857b7b4426f4e3c98c1
environment	testing	7734a6b6a8644857b7b4426f4e3c98c1
developer	automated-test	7734a6b6a8644857b7b4426f4e3c98c1
mlflow.runName	test-run-api	7734a6b6a8644857b7b4426f4e3c98c1
test	true	5676325e5319435f81b8944fb0aee554
environment	testing	5676325e5319435f81b8944fb0aee554
developer	automated-test	5676325e5319435f81b8944fb0aee554
mlflow.runName	test-run-finish	5676325e5319435f81b8944fb0aee554
test	true	a0e125ef045e4ad3ab2d773d6525b510
environment	testing	a0e125ef045e4ad3ab2d773d6525b510
developer	automated-test	a0e125ef045e4ad3ab2d773d6525b510
mlflow.runName	test-run-artifacts	a0e125ef045e4ad3ab2d773d6525b510
mlflow.user	axelofwar	0cc425fc72c0423daf783c62eba213b2
mlflow.source.name	-c	0cc425fc72c0423daf783c62eba213b2
mlflow.source.type	LOCAL	0cc425fc72c0423daf783c62eba213b2
test	true	0cc425fc72c0423daf783c62eba213b2
environment	testing	0cc425fc72c0423daf783c62eba213b2
developer	automated-test	0cc425fc72c0423daf783c62eba213b2
mlflow.runName	burly-bat-656	0cc425fc72c0423daf783c62eba213b2
mlflow.log-model.history	[{"run_id": "0cc425fc72c0423daf783c62eba213b2", "artifact_path": "model", "utc_time_created": "2025-11-23 06:18:08.240013", "model_uuid": "21738e9183654671aabc09674a642060", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	0cc425fc72c0423daf783c62eba213b2
test	true	af5f45170fb6421c8be52d5a9badd78f
environment	testing	af5f45170fb6421c8be52d5a9badd78f
developer	automated-test	af5f45170fb6421c8be52d5a9badd78f
mlflow.runName	test-run-complete	af5f45170fb6421c8be52d5a9badd78f
test	true	b3013958ed304125af6d52f921f83e96
mlflow.runName	test-run-incomplete	b3013958ed304125af6d52f921f83e96
test	true	2c0e1cb5cf4c49fbb6d10aeca893e7f2
environment	testing	2c0e1cb5cf4c49fbb6d10aeca893e7f2
developer	automated-test	2c0e1cb5cf4c49fbb6d10aeca893e7f2
mlflow.runName	test-run-api	2c0e1cb5cf4c49fbb6d10aeca893e7f2
test	true	c61fa02a83884a91986da3e909df78c7
environment	testing	c61fa02a83884a91986da3e909df78c7
developer	automated-test	c61fa02a83884a91986da3e909df78c7
mlflow.runName	test-run-finish	c61fa02a83884a91986da3e909df78c7
test	true	bae41274e3c74d2494a86c275ffdb55b
environment	testing	bae41274e3c74d2494a86c275ffdb55b
developer	automated-test	bae41274e3c74d2494a86c275ffdb55b
mlflow.runName	test-run-artifacts	bae41274e3c74d2494a86c275ffdb55b
mlflow.user	axelofwar	502dd5c855134fb3a6988473649b5664
mlflow.source.name	-c	502dd5c855134fb3a6988473649b5664
mlflow.source.type	LOCAL	502dd5c855134fb3a6988473649b5664
test	true	502dd5c855134fb3a6988473649b5664
environment	testing	502dd5c855134fb3a6988473649b5664
developer	automated-test	502dd5c855134fb3a6988473649b5664
mlflow.runName	smiling-shad-245	502dd5c855134fb3a6988473649b5664
mlflow.log-model.history	[{"run_id": "502dd5c855134fb3a6988473649b5664", "artifact_path": "model", "utc_time_created": "2025-11-23 06:23:23.788663", "model_uuid": "5d5c7ac7b5934d66ac2f6642f56f7524", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	502dd5c855134fb3a6988473649b5664
test	true	3bc1622c781b4364a0d7af2e5792713a
environment	testing	3bc1622c781b4364a0d7af2e5792713a
developer	automated-test	3bc1622c781b4364a0d7af2e5792713a
mlflow.runName	test-run-complete	3bc1622c781b4364a0d7af2e5792713a
test	true	8aef31b395d6434d81efcdd3c9719c45
mlflow.runName	test-run-incomplete	8aef31b395d6434d81efcdd3c9719c45
test	true	2ba330ec13d74c28a7c20bbc9ebd3f36
environment	testing	2ba330ec13d74c28a7c20bbc9ebd3f36
developer	automated-test	2ba330ec13d74c28a7c20bbc9ebd3f36
mlflow.runName	test-run-api	2ba330ec13d74c28a7c20bbc9ebd3f36
test	true	34bd95a0ca9343b2871fdf5e485ace87
environment	testing	34bd95a0ca9343b2871fdf5e485ace87
developer	automated-test	34bd95a0ca9343b2871fdf5e485ace87
mlflow.runName	test-run-finish	34bd95a0ca9343b2871fdf5e485ace87
test	true	ecf876c9e3414f7bb8d2a7b389ec65fc
environment	testing	ecf876c9e3414f7bb8d2a7b389ec65fc
developer	automated-test	ecf876c9e3414f7bb8d2a7b389ec65fc
mlflow.runName	test-run-artifacts	ecf876c9e3414f7bb8d2a7b389ec65fc
mlflow.user	axelofwar	dbd9e5cf1b2d4c73bbd83b15f7912b64
mlflow.source.name	-c	dbd9e5cf1b2d4c73bbd83b15f7912b64
mlflow.source.type	LOCAL	dbd9e5cf1b2d4c73bbd83b15f7912b64
test	true	dbd9e5cf1b2d4c73bbd83b15f7912b64
environment	testing	dbd9e5cf1b2d4c73bbd83b15f7912b64
developer	automated-test	dbd9e5cf1b2d4c73bbd83b15f7912b64
mlflow.runName	orderly-jay-477	dbd9e5cf1b2d4c73bbd83b15f7912b64
mlflow.log-model.history	[{"run_id": "dbd9e5cf1b2d4c73bbd83b15f7912b64", "artifact_path": "model", "utc_time_created": "2025-11-23 06:24:06.802140", "model_uuid": "1abd377ed3f9453f9b163c7777d6119b", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	dbd9e5cf1b2d4c73bbd83b15f7912b64
test	true	b1098b2af029454397b9d09e5888d264
environment	testing	b1098b2af029454397b9d09e5888d264
developer	automated-test	b1098b2af029454397b9d09e5888d264
mlflow.runName	test-run-complete	b1098b2af029454397b9d09e5888d264
test	true	8829a62a417044bb842a323a9c011827
mlflow.runName	test-run-incomplete	8829a62a417044bb842a323a9c011827
test	true	b3fdaa98273c42a3af405bb30cfd718c
environment	testing	b3fdaa98273c42a3af405bb30cfd718c
developer	automated-test	b3fdaa98273c42a3af405bb30cfd718c
mlflow.runName	test-run-api	b3fdaa98273c42a3af405bb30cfd718c
test	true	5ceddc2c239c4cb4a4622679c46e3e99
environment	testing	5ceddc2c239c4cb4a4622679c46e3e99
developer	automated-test	5ceddc2c239c4cb4a4622679c46e3e99
mlflow.runName	test-run-finish	5ceddc2c239c4cb4a4622679c46e3e99
test	true	313dc2b7a0aa4a729aa014c0ff7f00f1
environment	testing	313dc2b7a0aa4a729aa014c0ff7f00f1
developer	automated-test	313dc2b7a0aa4a729aa014c0ff7f00f1
mlflow.runName	test-run-artifacts	313dc2b7a0aa4a729aa014c0ff7f00f1
mlflow.user	axelofwar	20f8e1d304de4c05b0703edd00012e81
mlflow.source.name	-c	20f8e1d304de4c05b0703edd00012e81
mlflow.source.type	LOCAL	20f8e1d304de4c05b0703edd00012e81
test	true	20f8e1d304de4c05b0703edd00012e81
environment	testing	20f8e1d304de4c05b0703edd00012e81
developer	automated-test	20f8e1d304de4c05b0703edd00012e81
mlflow.runName	unique-sow-584	20f8e1d304de4c05b0703edd00012e81
mlflow.log-model.history	[{"run_id": "20f8e1d304de4c05b0703edd00012e81", "artifact_path": "model", "utc_time_created": "2025-11-23 06:24:20.354258", "model_uuid": "06ac4b8cab1f4f92abd7153e9fd05370", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	20f8e1d304de4c05b0703edd00012e81
test	true	9c0f6c167f024f3782354ba3592c7317
environment	testing	9c0f6c167f024f3782354ba3592c7317
developer	automated-test	9c0f6c167f024f3782354ba3592c7317
mlflow.runName	test-run-complete	9c0f6c167f024f3782354ba3592c7317
test	true	2b14de23630f4c5d975198dcbb67762f
mlflow.runName	test-run-incomplete	2b14de23630f4c5d975198dcbb67762f
test	true	8a4322a00f804382815b509434cb108f
environment	testing	8a4322a00f804382815b509434cb108f
developer	automated-test	8a4322a00f804382815b509434cb108f
mlflow.runName	test-run-api	8a4322a00f804382815b509434cb108f
test	true	9d5caef3e5514679b544ecc83fb9f34c
environment	testing	9d5caef3e5514679b544ecc83fb9f34c
developer	automated-test	9d5caef3e5514679b544ecc83fb9f34c
mlflow.runName	test-run-finish	9d5caef3e5514679b544ecc83fb9f34c
test	true	a229f5d2cc8641569016abf3f5935383
environment	testing	a229f5d2cc8641569016abf3f5935383
developer	automated-test	a229f5d2cc8641569016abf3f5935383
mlflow.runName	test-run-artifacts	a229f5d2cc8641569016abf3f5935383
mlflow.user	axelofwar	31441990305b4cf484775e1bfd2a039c
mlflow.source.name	-c	31441990305b4cf484775e1bfd2a039c
mlflow.source.type	LOCAL	31441990305b4cf484775e1bfd2a039c
test	true	31441990305b4cf484775e1bfd2a039c
environment	testing	31441990305b4cf484775e1bfd2a039c
developer	automated-test	31441990305b4cf484775e1bfd2a039c
mlflow.runName	calm-mole-822	31441990305b4cf484775e1bfd2a039c
mlflow.log-model.history	[{"run_id": "31441990305b4cf484775e1bfd2a039c", "artifact_path": "model", "utc_time_created": "2025-11-23 06:26:58.522835", "model_uuid": "4c35b76570c7415181847a40145ae7ea", "flavors": {"python_function": {"model_path": "model.pkl", "predict_fn": "predict", "loader_module": "mlflow.sklearn", "python_version": "3.12.3", "env": {"conda": "conda.yaml", "virtualenv": "python_env.yaml"}}, "sklearn": {"pickled_model": "model.pkl", "sklearn_version": "1.5.2", "serialization_format": "cloudpickle", "code": null}}}]	31441990305b4cf484775e1bfd2a039c
\.


--
-- Data for Name: trace_info; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.trace_info (request_id, experiment_id, timestamp_ms, execution_time_ms, status) FROM stdin;
\.


--
-- Data for Name: trace_request_metadata; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.trace_request_metadata (key, value, request_id) FROM stdin;
\.


--
-- Data for Name: trace_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.trace_tags (key, value, request_id) FROM stdin;
\.


--
-- Name: experiments_experiment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mlflow
--

SELECT pg_catalog.setval('public.experiments_experiment_id_seq', 23, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: datasets dataset_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT dataset_pk PRIMARY KEY (experiment_id, name, digest);


--
-- Name: experiments experiment_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiment_pk PRIMARY KEY (experiment_id);


--
-- Name: experiment_tags experiment_tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiment_tags
    ADD CONSTRAINT experiment_tag_pk PRIMARY KEY (key, experiment_id);


--
-- Name: experiments experiments_name_key; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_name_key UNIQUE (name);


--
-- Name: input_tags input_tags_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.input_tags
    ADD CONSTRAINT input_tags_pk PRIMARY KEY (input_uuid, name);


--
-- Name: inputs inputs_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.inputs
    ADD CONSTRAINT inputs_pk PRIMARY KEY (source_type, source_id, destination_type, destination_id);


--
-- Name: latest_metrics latest_metric_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.latest_metrics
    ADD CONSTRAINT latest_metric_pk PRIMARY KEY (key, run_uuid);


--
-- Name: metrics metric_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.metrics
    ADD CONSTRAINT metric_pk PRIMARY KEY (key, "timestamp", step, run_uuid, value, is_nan);


--
-- Name: model_versions model_version_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.model_versions
    ADD CONSTRAINT model_version_pk PRIMARY KEY (name, version);


--
-- Name: model_version_tags model_version_tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.model_version_tags
    ADD CONSTRAINT model_version_tag_pk PRIMARY KEY (key, name, version);


--
-- Name: params param_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.params
    ADD CONSTRAINT param_pk PRIMARY KEY (key, run_uuid);


--
-- Name: registered_model_aliases registered_model_alias_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_model_aliases
    ADD CONSTRAINT registered_model_alias_pk PRIMARY KEY (name, alias);


--
-- Name: registered_models registered_model_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_models
    ADD CONSTRAINT registered_model_pk PRIMARY KEY (name);


--
-- Name: registered_model_tags registered_model_tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_model_tags
    ADD CONSTRAINT registered_model_tag_pk PRIMARY KEY (key, name);


--
-- Name: runs run_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT run_pk PRIMARY KEY (run_uuid);


--
-- Name: tags tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tag_pk PRIMARY KEY (key, run_uuid);


--
-- Name: trace_info trace_info_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_info
    ADD CONSTRAINT trace_info_pk PRIMARY KEY (request_id);


--
-- Name: trace_request_metadata trace_request_metadata_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_request_metadata
    ADD CONSTRAINT trace_request_metadata_pk PRIMARY KEY (key, request_id);


--
-- Name: trace_tags trace_tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_tags
    ADD CONSTRAINT trace_tag_pk PRIMARY KEY (key, request_id);


--
-- Name: index_datasets_dataset_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_datasets_dataset_uuid ON public.datasets USING btree (dataset_uuid);


--
-- Name: index_datasets_experiment_id_dataset_source_type; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_datasets_experiment_id_dataset_source_type ON public.datasets USING btree (experiment_id, dataset_source_type);


--
-- Name: index_inputs_destination_type_destination_id_source_type; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_inputs_destination_type_destination_id_source_type ON public.inputs USING btree (destination_type, destination_id, source_type);


--
-- Name: index_inputs_input_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_inputs_input_uuid ON public.inputs USING btree (input_uuid);


--
-- Name: index_latest_metrics_run_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_latest_metrics_run_uuid ON public.latest_metrics USING btree (run_uuid);


--
-- Name: index_metrics_run_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_metrics_run_uuid ON public.metrics USING btree (run_uuid);


--
-- Name: index_params_run_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_params_run_uuid ON public.params USING btree (run_uuid);


--
-- Name: index_tags_run_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_tags_run_uuid ON public.tags USING btree (run_uuid);


--
-- Name: index_trace_info_experiment_id_timestamp_ms; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_trace_info_experiment_id_timestamp_ms ON public.trace_info USING btree (experiment_id, timestamp_ms);


--
-- Name: index_trace_request_metadata_request_id; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_trace_request_metadata_request_id ON public.trace_request_metadata USING btree (request_id);


--
-- Name: index_trace_tags_request_id; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_trace_tags_request_id ON public.trace_tags USING btree (request_id);


--
-- Name: datasets datasets_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(experiment_id);


--
-- Name: experiment_tags experiment_tags_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiment_tags
    ADD CONSTRAINT experiment_tags_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(experiment_id);


--
-- Name: trace_info fk_trace_info_experiment_id; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_info
    ADD CONSTRAINT fk_trace_info_experiment_id FOREIGN KEY (experiment_id) REFERENCES public.experiments(experiment_id);


--
-- Name: trace_request_metadata fk_trace_request_metadata_request_id; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_request_metadata
    ADD CONSTRAINT fk_trace_request_metadata_request_id FOREIGN KEY (request_id) REFERENCES public.trace_info(request_id) ON DELETE CASCADE;


--
-- Name: trace_tags fk_trace_tags_request_id; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_tags
    ADD CONSTRAINT fk_trace_tags_request_id FOREIGN KEY (request_id) REFERENCES public.trace_info(request_id) ON DELETE CASCADE;


--
-- Name: latest_metrics latest_metrics_run_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.latest_metrics
    ADD CONSTRAINT latest_metrics_run_uuid_fkey FOREIGN KEY (run_uuid) REFERENCES public.runs(run_uuid);


--
-- Name: metrics metrics_run_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.metrics
    ADD CONSTRAINT metrics_run_uuid_fkey FOREIGN KEY (run_uuid) REFERENCES public.runs(run_uuid);


--
-- Name: model_version_tags model_version_tags_name_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.model_version_tags
    ADD CONSTRAINT model_version_tags_name_version_fkey FOREIGN KEY (name, version) REFERENCES public.model_versions(name, version) ON UPDATE CASCADE;


--
-- Name: model_versions model_versions_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.model_versions
    ADD CONSTRAINT model_versions_name_fkey FOREIGN KEY (name) REFERENCES public.registered_models(name) ON UPDATE CASCADE;


--
-- Name: params params_run_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.params
    ADD CONSTRAINT params_run_uuid_fkey FOREIGN KEY (run_uuid) REFERENCES public.runs(run_uuid);


--
-- Name: registered_model_aliases registered_model_alias_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_model_aliases
    ADD CONSTRAINT registered_model_alias_name_fkey FOREIGN KEY (name) REFERENCES public.registered_models(name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: registered_model_tags registered_model_tags_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_model_tags
    ADD CONSTRAINT registered_model_tags_name_fkey FOREIGN KEY (name) REFERENCES public.registered_models(name) ON UPDATE CASCADE;


--
-- Name: runs runs_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(experiment_id);


--
-- Name: tags tags_run_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_run_uuid_fkey FOREIGN KEY (run_uuid) REFERENCES public.runs(run_uuid);


--
-- PostgreSQL database dump complete
--

\unrestrict 5HZHA68YimRR2zu4AuGTBEzhQbslAp1gTefcYlxQqUVmdh7PVxZqb9kL2niSgo9

