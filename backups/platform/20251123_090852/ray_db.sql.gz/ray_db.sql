--
-- PostgreSQL database dump
--

\restrict 4lCWDM11wLmiD6eV5CSuLbSMKJpHBu3PHZuf0zEfMPd9U9lCbOnWqhziOI4pifx

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.jobs (
    job_id uuid DEFAULT gen_random_uuid() NOT NULL,
    ray_job_id character varying(255) NOT NULL,
    user_id uuid,
    status character varying(50) NOT NULL,
    entrypoint text NOT NULL,
    runtime_env jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_message text
);


ALTER TABLE public.jobs OWNER TO ray_compute;

--
-- Name: user_quotas; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.user_quotas (
    quota_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    max_concurrent_jobs integer DEFAULT 5,
    max_cpu_per_job integer DEFAULT 4,
    max_memory_per_job_gb integer DEFAULT 16,
    max_gpu_per_job integer DEFAULT 1,
    total_job_runtime_hours_per_day integer DEFAULT 24,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_quotas OWNER TO ray_compute;

--
-- Name: users; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.users (
    user_id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(255),
    email character varying(255),
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    oauth_sub character varying(255),
    api_key_hash character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    is_active boolean DEFAULT true,
    is_suspended boolean DEFAULT false,
    suspension_reason text,
    suspended_at timestamp without time zone,
    suspended_by uuid
);


ALTER TABLE public.users OWNER TO ray_compute;

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.jobs (job_id, ray_job_id, user_id, status, entrypoint, runtime_env, metadata, created_at, started_at, completed_at, error_message) FROM stdin;
\.


--
-- Data for Name: user_quotas; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.user_quotas (quota_id, user_id, max_concurrent_jobs, max_cpu_per_job, max_memory_per_job_gb, max_gpu_per_job, total_job_runtime_hours_per_day, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.users (user_id, username, email, role, oauth_sub, api_key_hash, created_at, updated_at, last_login, is_active, is_suspended, suspension_reason, suspended_at, suspended_by) FROM stdin;
\.


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (job_id);


--
-- Name: jobs jobs_ray_job_id_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_ray_job_id_key UNIQUE (ray_job_id);


--
-- Name: user_quotas user_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.user_quotas
    ADD CONSTRAINT user_quotas_pkey PRIMARY KEY (quota_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_oauth_sub_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_oauth_sub_key UNIQUE (oauth_sub);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_jobs_status; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_jobs_status ON public.jobs USING btree (status);


--
-- Name: idx_jobs_user_id; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_jobs_user_id ON public.jobs USING btree (user_id);


--
-- Name: idx_users_oauth_sub; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_users_oauth_sub ON public.users USING btree (oauth_sub);


--
-- Name: jobs jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: user_quotas user_quotas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.user_quotas
    ADD CONSTRAINT user_quotas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4lCWDM11wLmiD6eV5CSuLbSMKJpHBu3PHZuf0zEfMPd9U9lCbOnWqhziOI4pifx

