--
-- PostgreSQL database dump
--

\restrict jChDALx1RF4hexPlaX2XqxcmFBXXoCFOhj9d1dbWq44tyXBK65KsiMBaPb57hOY

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict jChDALx1RF4hexPlaX2XqxcmFBXXoCFOhj9d1dbWq44tyXBK65KsiMBaPb57hOY

