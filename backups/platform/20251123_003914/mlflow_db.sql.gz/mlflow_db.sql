--
-- PostgreSQL database dump
--

\restrict x7C9mcqOEBkls85j85oYS3gTTKzOS00jyAlS5elsboLe7cT5ONCojzHPRczRqRX

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO mlflow;

--
-- Name: datasets; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.datasets (
    dataset_uuid character varying(36) NOT NULL,
    experiment_id integer NOT NULL,
    name character varying(500) NOT NULL,
    digest character varying(36) NOT NULL,
    dataset_source_type character varying(36) NOT NULL,
    dataset_source text NOT NULL,
    dataset_schema text,
    dataset_profile text
);


ALTER TABLE public.datasets OWNER TO mlflow;

--
-- Name: experiment_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.experiment_tags (
    key character varying(250) NOT NULL,
    value character varying(5000),
    experiment_id integer NOT NULL
);


ALTER TABLE public.experiment_tags OWNER TO mlflow;

--
-- Name: experiments; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.experiments (
    experiment_id integer NOT NULL,
    name character varying(256) NOT NULL,
    artifact_location character varying(256),
    lifecycle_stage character varying(32),
    creation_time bigint,
    last_update_time bigint,
    CONSTRAINT experiments_lifecycle_stage CHECK (((lifecycle_stage)::text = ANY ((ARRAY['active'::character varying, 'deleted'::character varying])::text[])))
);


ALTER TABLE public.experiments OWNER TO mlflow;

--
-- Name: experiments_experiment_id_seq; Type: SEQUENCE; Schema: public; Owner: mlflow
--

CREATE SEQUENCE public.experiments_experiment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.experiments_experiment_id_seq OWNER TO mlflow;

--
-- Name: experiments_experiment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mlflow
--

ALTER SEQUENCE public.experiments_experiment_id_seq OWNED BY public.experiments.experiment_id;


--
-- Name: input_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.input_tags (
    input_uuid character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(500) NOT NULL
);


ALTER TABLE public.input_tags OWNER TO mlflow;

--
-- Name: inputs; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.inputs (
    input_uuid character varying(36) NOT NULL,
    source_type character varying(36) NOT NULL,
    source_id character varying(36) NOT NULL,
    destination_type character varying(36) NOT NULL,
    destination_id character varying(36) NOT NULL
);


ALTER TABLE public.inputs OWNER TO mlflow;

--
-- Name: latest_metrics; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.latest_metrics (
    key character varying(250) NOT NULL,
    value double precision NOT NULL,
    "timestamp" bigint,
    step bigint NOT NULL,
    is_nan boolean NOT NULL,
    run_uuid character varying(32) NOT NULL
);


ALTER TABLE public.latest_metrics OWNER TO mlflow;

--
-- Name: metrics; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.metrics (
    key character varying(250) NOT NULL,
    value double precision NOT NULL,
    "timestamp" bigint NOT NULL,
    run_uuid character varying(32) NOT NULL,
    step bigint DEFAULT '0'::bigint NOT NULL,
    is_nan boolean DEFAULT false NOT NULL
);


ALTER TABLE public.metrics OWNER TO mlflow;

--
-- Name: model_version_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.model_version_tags (
    key character varying(250) NOT NULL,
    value character varying(5000),
    name character varying(256) NOT NULL,
    version integer NOT NULL
);


ALTER TABLE public.model_version_tags OWNER TO mlflow;

--
-- Name: model_versions; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.model_versions (
    name character varying(256) NOT NULL,
    version integer NOT NULL,
    creation_time bigint,
    last_updated_time bigint,
    description character varying(5000),
    user_id character varying(256),
    current_stage character varying(20),
    source character varying(500),
    run_id character varying(32),
    status character varying(20),
    status_message character varying(500),
    run_link character varying(500),
    storage_location character varying(500)
);


ALTER TABLE public.model_versions OWNER TO mlflow;

--
-- Name: params; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.params (
    key character varying(250) NOT NULL,
    value character varying(8000) NOT NULL,
    run_uuid character varying(32) NOT NULL
);


ALTER TABLE public.params OWNER TO mlflow;

--
-- Name: registered_model_aliases; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.registered_model_aliases (
    alias character varying(256) NOT NULL,
    version integer NOT NULL,
    name character varying(256) NOT NULL
);


ALTER TABLE public.registered_model_aliases OWNER TO mlflow;

--
-- Name: registered_model_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.registered_model_tags (
    key character varying(250) NOT NULL,
    value character varying(5000),
    name character varying(256) NOT NULL
);


ALTER TABLE public.registered_model_tags OWNER TO mlflow;

--
-- Name: registered_models; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.registered_models (
    name character varying(256) NOT NULL,
    creation_time bigint,
    last_updated_time bigint,
    description character varying(5000)
);


ALTER TABLE public.registered_models OWNER TO mlflow;

--
-- Name: runs; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.runs (
    run_uuid character varying(32) NOT NULL,
    name character varying(250),
    source_type character varying(20),
    source_name character varying(500),
    entry_point_name character varying(50),
    user_id character varying(256),
    status character varying(9),
    start_time bigint,
    end_time bigint,
    source_version character varying(50),
    lifecycle_stage character varying(20),
    artifact_uri character varying(200),
    experiment_id integer,
    deleted_time bigint,
    CONSTRAINT runs_lifecycle_stage CHECK (((lifecycle_stage)::text = ANY ((ARRAY['active'::character varying, 'deleted'::character varying])::text[]))),
    CONSTRAINT runs_status_check CHECK (((status)::text = ANY ((ARRAY['SCHEDULED'::character varying, 'FAILED'::character varying, 'FINISHED'::character varying, 'RUNNING'::character varying, 'KILLED'::character varying])::text[]))),
    CONSTRAINT source_type CHECK (((source_type)::text = ANY ((ARRAY['NOTEBOOK'::character varying, 'JOB'::character varying, 'LOCAL'::character varying, 'UNKNOWN'::character varying, 'PROJECT'::character varying])::text[])))
);


ALTER TABLE public.runs OWNER TO mlflow;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.tags (
    key character varying(250) NOT NULL,
    value character varying(8000),
    run_uuid character varying(32) NOT NULL
);


ALTER TABLE public.tags OWNER TO mlflow;

--
-- Name: trace_info; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.trace_info (
    request_id character varying(50) NOT NULL,
    experiment_id integer NOT NULL,
    timestamp_ms bigint NOT NULL,
    execution_time_ms bigint,
    status character varying(50) NOT NULL
);


ALTER TABLE public.trace_info OWNER TO mlflow;

--
-- Name: trace_request_metadata; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.trace_request_metadata (
    key character varying(250) NOT NULL,
    value character varying(8000),
    request_id character varying(50) NOT NULL
);


ALTER TABLE public.trace_request_metadata OWNER TO mlflow;

--
-- Name: trace_tags; Type: TABLE; Schema: public; Owner: mlflow
--

CREATE TABLE public.trace_tags (
    key character varying(250) NOT NULL,
    value character varying(8000),
    request_id character varying(50) NOT NULL
);


ALTER TABLE public.trace_tags OWNER TO mlflow;

--
-- Name: experiments experiment_id; Type: DEFAULT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiments ALTER COLUMN experiment_id SET DEFAULT nextval('public.experiments_experiment_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.alembic_version (version_num) FROM stdin;
f5a4f2784254
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.datasets (dataset_uuid, experiment_id, name, digest, dataset_source_type, dataset_source, dataset_schema, dataset_profile) FROM stdin;
\.


--
-- Data for Name: experiment_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.experiment_tags (key, value, experiment_id) FROM stdin;
environment	dev	1
purpose	training	1
project	pii-pro	1
environment	staging	2
purpose	comparison	2
project	pii-pro	2
environment	benchmarking	3
purpose	performance	3
project	pii-pro	3
environment	production	4
purpose	deployment	4
project	pii-pro	4
environment	data	5
purpose	dataset-management	5
project	pii-pro	5
created_by	api_test	9
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.experiments (experiment_id, name, artifact_location, lifecycle_stage, creation_time, last_update_time) FROM stdin;
0	Default	/mlflow/artifacts/0	active	1763863832663	1763863832663
1	Development-Training	/mlflow/artifacts/1	active	1763866743662	1763866743662
2	Staging-Model-Comparison	/mlflow/artifacts/2	active	1763866744157	1763866744157
3	Performance-Benchmarking	/mlflow/artifacts/3	active	1763866744168	1763866744168
4	Production-Candidates	/mlflow/artifacts/4	active	1763866744177	1763866744177
5	Dataset-Registry	/mlflow/artifacts/5	active	1763866744186	1763866744186
6	test-schema-validation	/mlflow/artifacts/6	active	1763874106903	1763874106903
9	test-api-experiment	/mlflow/artifacts/test-api-experiment	active	1763875031437	1763875031437
\.


--
-- Data for Name: input_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.input_tags (input_uuid, name, value) FROM stdin;
\.


--
-- Data for Name: inputs; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.inputs (input_uuid, source_type, source_id, destination_type, destination_id) FROM stdin;
\.


--
-- Data for Name: latest_metrics; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.latest_metrics (key, value, "timestamp", step, is_nan, run_uuid) FROM stdin;
accuracy	0.95	1763875330736	1	f	648063c29c3043b0bc791f5853b5aeb1
loss	0.05	1763875330736	1	f	648063c29c3043b0bc791f5853b5aeb1
accuracy	0.95	1763876003496	1	f	30b603bc2b47497ab5ea091302c7dd01
loss	0.05	1763876003496	1	f	30b603bc2b47497ab5ea091302c7dd01
\.


--
-- Data for Name: metrics; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.metrics (key, value, "timestamp", run_uuid, step, is_nan) FROM stdin;
accuracy	0.95	1763875330736	648063c29c3043b0bc791f5853b5aeb1	1	f
loss	0.05	1763875330736	648063c29c3043b0bc791f5853b5aeb1	1	f
accuracy	0.95	1763876003496	30b603bc2b47497ab5ea091302c7dd01	1	f
loss	0.05	1763876003496	30b603bc2b47497ab5ea091302c7dd01	1	f
\.


--
-- Data for Name: model_version_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.model_version_tags (key, value, name, version) FROM stdin;
\.


--
-- Data for Name: model_versions; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.model_versions (name, version, creation_time, last_updated_time, description, user_id, current_stage, source, run_id, status, status_message, run_link, storage_location) FROM stdin;
\.


--
-- Data for Name: params; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.params (key, value, run_uuid) FROM stdin;
learning_rate	0.001	9d711bc7515c4b3f87fc290a69b48cf8
batch_size	32	9d711bc7515c4b3f87fc290a69b48cf8
test_param	1.0	f84789be558244dfa8f7f4e70ae6fb88
learning_rate	0.001	4d05835d44ff4ca8a80c9d5916e8a2c0
batch_size	32	4d05835d44ff4ca8a80c9d5916e8a2c0
test_param	1.0	3cb8c052bcd4414c912532d55d835cbf
learning_rate	0.001	d298a365f0e244b69ec5b3f0a7c73fab
batch_size	32	d298a365f0e244b69ec5b3f0a7c73fab
test_param	1.0	648063c29c3043b0bc791f5853b5aeb1
learning_rate	0.001	8781893afbbd429eb4502a7a682730ae
batch_size	32	8781893afbbd429eb4502a7a682730ae
test_param	1.0	30b603bc2b47497ab5ea091302c7dd01
\.


--
-- Data for Name: registered_model_aliases; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.registered_model_aliases (alias, version, name) FROM stdin;
\.


--
-- Data for Name: registered_model_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.registered_model_tags (key, value, name) FROM stdin;
\.


--
-- Data for Name: registered_models; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.registered_models (name, creation_time, last_updated_time, description) FROM stdin;
\.


--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.runs (run_uuid, name, source_type, source_name, entry_point_name, user_id, status, start_time, end_time, source_version, lifecycle_stage, artifact_uri, experiment_id, deleted_time) FROM stdin;
6b5bcd79714249a7865101bd416e7784	test-run-fixed	UNKNOWN			unknown	RUNNING	1763874349869	\N		active	/mlflow/artifacts/6/6b5bcd79714249a7865101bd416e7784/artifacts	6	\N
339b271f92574ba18505c8c3ecde056f	test-run-fixed	UNKNOWN			unknown	RUNNING	1763874362115	\N		active	/mlflow/artifacts/6/339b271f92574ba18505c8c3ecde056f/artifacts	6	\N
9d711bc7515c4b3f87fc290a69b48cf8	test-run-complete	UNKNOWN			unknown	FINISHED	1763874372308	1763874372340		active	/mlflow/artifacts/6/9d711bc7515c4b3f87fc290a69b48cf8/artifacts	6	\N
0c5f2bf86bce481c80872f0c220f3801	test-run-incomplete	UNKNOWN			unknown	RUNNING	1763874372376	\N		active	/mlflow/artifacts/6/0c5f2bf86bce481c80872f0c220f3801/artifacts	6	\N
715ee2c5cf084fdcbf686b7d297d19ee	test-run-finish	UNKNOWN			unknown	FINISHED	1763874372993	1763874373005		active	/mlflow/artifacts/6/715ee2c5cf084fdcbf686b7d297d19ee/artifacts	6	\N
f84789be558244dfa8f7f4e70ae6fb88	test-run-api	UNKNOWN			unknown	FINISHED	1763874372913	1763874374282		active	/mlflow/artifacts/6/f84789be558244dfa8f7f4e70ae6fb88/artifacts	6	\N
4d05835d44ff4ca8a80c9d5916e8a2c0	test-run-complete	UNKNOWN			unknown	FINISHED	1763875040752	1763875040798		active	/mlflow/artifacts/6/4d05835d44ff4ca8a80c9d5916e8a2c0/artifacts	6	\N
72a74314b49f43be88f1c6cfa1a791e9	test-run-incomplete	UNKNOWN			unknown	RUNNING	1763875040838	\N		active	/mlflow/artifacts/6/72a74314b49f43be88f1c6cfa1a791e9/artifacts	6	\N
bef091ff84754bf6b6f7c0c562593fa1	test-run-finish	UNKNOWN			unknown	FINISHED	1763875042769	1763875042811		active	/mlflow/artifacts/6/bef091ff84754bf6b6f7c0c562593fa1/artifacts	6	\N
3cb8c052bcd4414c912532d55d835cbf	test-run-api	UNKNOWN			unknown	FINISHED	1763875041417	1763875042825		active	/mlflow/artifacts/6/3cb8c052bcd4414c912532d55d835cbf/artifacts	6	\N
9c88cdcb290d45eabf9b123c7cfae98b	metrics-test	UNKNOWN			unknown	RUNNING	1763875059833	\N		active	/mlflow/artifacts/6/9c88cdcb290d45eabf9b123c7cfae98b/artifacts	6	\N
d298a365f0e244b69ec5b3f0a7c73fab	test-run-complete	UNKNOWN			unknown	FINISHED	1763875327348	1763875329009		active	/mlflow/artifacts/6/d298a365f0e244b69ec5b3f0a7c73fab/artifacts	6	\N
cf461b4b5b5c4fb2b97bc817bbd8cb39	test-run-incomplete	UNKNOWN			unknown	RUNNING	1763875329052	\N		active	/mlflow/artifacts/6/cf461b4b5b5c4fb2b97bc817bbd8cb39/artifacts	6	\N
08907a2ee5a74041aaf4002bac857d7d	test-run-finish	UNKNOWN			unknown	FINISHED	1763875330769	1763875330782		active	/mlflow/artifacts/6/08907a2ee5a74041aaf4002bac857d7d/artifacts	6	\N
648063c29c3043b0bc791f5853b5aeb1	test-run-api	UNKNOWN			unknown	FINISHED	1763875329641	1763875330793		active	/mlflow/artifacts/6/648063c29c3043b0bc791f5853b5aeb1/artifacts	6	\N
8781893afbbd429eb4502a7a682730ae	test-run-complete	UNKNOWN			unknown	FINISHED	1763876001221	1763876002703		active	/mlflow/artifacts/6/8781893afbbd429eb4502a7a682730ae/artifacts	6	\N
5987cb805c1c4e3d93678d117da116aa	test-run-incomplete	UNKNOWN			unknown	RUNNING	1763876002749	\N		active	/mlflow/artifacts/6/5987cb805c1c4e3d93678d117da116aa/artifacts	6	\N
7bd4a3ddd84d44a9b6586750ea2efde7	test-run-finish	UNKNOWN			unknown	FINISHED	1763876003734	1763876003924		active	/mlflow/artifacts/6/7bd4a3ddd84d44a9b6586750ea2efde7/artifacts	6	\N
30b603bc2b47497ab5ea091302c7dd01	test-run-api	UNKNOWN			unknown	FINISHED	1763876003336	1763876004012		active	/mlflow/artifacts/6/30b603bc2b47497ab5ea091302c7dd01/artifacts	6	\N
640a310ff98043ca8d51c9579a2caa37	test-run-artifacts	UNKNOWN			unknown	FINISHED	1763876004269	1763876004374		active	/mlflow/artifacts/6/640a310ff98043ca8d51c9579a2caa37/artifacts	6	\N
9987474eed4c450eb5dcd74b333f63fc	nervous-ant-138	UNKNOWN			axelofwar	FAILED	1763876007514	1763876009435		active	/mlflow/artifacts/6/9987474eed4c450eb5dcd74b333f63fc/artifacts	6	\N
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.tags (key, value, run_uuid) FROM stdin;
test	true	6b5bcd79714249a7865101bd416e7784
developer	automated-test	6b5bcd79714249a7865101bd416e7784
environment	testing	6b5bcd79714249a7865101bd416e7784
mlflow.runName	test-run-fixed	6b5bcd79714249a7865101bd416e7784
test	true	339b271f92574ba18505c8c3ecde056f
developer	automated-test	339b271f92574ba18505c8c3ecde056f
environment	testing	339b271f92574ba18505c8c3ecde056f
mlflow.runName	test-run-fixed	339b271f92574ba18505c8c3ecde056f
test	true	9d711bc7515c4b3f87fc290a69b48cf8
environment	testing	9d711bc7515c4b3f87fc290a69b48cf8
developer	automated-test	9d711bc7515c4b3f87fc290a69b48cf8
mlflow.runName	test-run-complete	9d711bc7515c4b3f87fc290a69b48cf8
test	true	0c5f2bf86bce481c80872f0c220f3801
mlflow.runName	test-run-incomplete	0c5f2bf86bce481c80872f0c220f3801
test	true	f84789be558244dfa8f7f4e70ae6fb88
environment	testing	f84789be558244dfa8f7f4e70ae6fb88
developer	automated-test	f84789be558244dfa8f7f4e70ae6fb88
mlflow.runName	test-run-api	f84789be558244dfa8f7f4e70ae6fb88
test	true	715ee2c5cf084fdcbf686b7d297d19ee
environment	testing	715ee2c5cf084fdcbf686b7d297d19ee
developer	automated-test	715ee2c5cf084fdcbf686b7d297d19ee
mlflow.runName	test-run-finish	715ee2c5cf084fdcbf686b7d297d19ee
test	true	4d05835d44ff4ca8a80c9d5916e8a2c0
environment	testing	4d05835d44ff4ca8a80c9d5916e8a2c0
developer	automated-test	4d05835d44ff4ca8a80c9d5916e8a2c0
mlflow.runName	test-run-complete	4d05835d44ff4ca8a80c9d5916e8a2c0
test	true	72a74314b49f43be88f1c6cfa1a791e9
mlflow.runName	test-run-incomplete	72a74314b49f43be88f1c6cfa1a791e9
test	true	3cb8c052bcd4414c912532d55d835cbf
environment	testing	3cb8c052bcd4414c912532d55d835cbf
developer	automated-test	3cb8c052bcd4414c912532d55d835cbf
mlflow.runName	test-run-api	3cb8c052bcd4414c912532d55d835cbf
test	true	bef091ff84754bf6b6f7c0c562593fa1
environment	testing	bef091ff84754bf6b6f7c0c562593fa1
developer	automated-test	bef091ff84754bf6b6f7c0c562593fa1
mlflow.runName	test-run-finish	bef091ff84754bf6b6f7c0c562593fa1
test	true	9c88cdcb290d45eabf9b123c7cfae98b
mlflow.runName	metrics-test	9c88cdcb290d45eabf9b123c7cfae98b
test	true	d298a365f0e244b69ec5b3f0a7c73fab
environment	testing	d298a365f0e244b69ec5b3f0a7c73fab
developer	automated-test	d298a365f0e244b69ec5b3f0a7c73fab
mlflow.runName	test-run-complete	d298a365f0e244b69ec5b3f0a7c73fab
test	true	cf461b4b5b5c4fb2b97bc817bbd8cb39
mlflow.runName	test-run-incomplete	cf461b4b5b5c4fb2b97bc817bbd8cb39
test	true	648063c29c3043b0bc791f5853b5aeb1
environment	testing	648063c29c3043b0bc791f5853b5aeb1
developer	automated-test	648063c29c3043b0bc791f5853b5aeb1
mlflow.runName	test-run-api	648063c29c3043b0bc791f5853b5aeb1
test	true	08907a2ee5a74041aaf4002bac857d7d
environment	testing	08907a2ee5a74041aaf4002bac857d7d
developer	automated-test	08907a2ee5a74041aaf4002bac857d7d
mlflow.runName	test-run-finish	08907a2ee5a74041aaf4002bac857d7d
test	true	8781893afbbd429eb4502a7a682730ae
environment	testing	8781893afbbd429eb4502a7a682730ae
developer	automated-test	8781893afbbd429eb4502a7a682730ae
mlflow.runName	test-run-complete	8781893afbbd429eb4502a7a682730ae
test	true	5987cb805c1c4e3d93678d117da116aa
mlflow.runName	test-run-incomplete	5987cb805c1c4e3d93678d117da116aa
test	true	30b603bc2b47497ab5ea091302c7dd01
environment	testing	30b603bc2b47497ab5ea091302c7dd01
developer	automated-test	30b603bc2b47497ab5ea091302c7dd01
mlflow.runName	test-run-api	30b603bc2b47497ab5ea091302c7dd01
test	true	7bd4a3ddd84d44a9b6586750ea2efde7
environment	testing	7bd4a3ddd84d44a9b6586750ea2efde7
developer	automated-test	7bd4a3ddd84d44a9b6586750ea2efde7
mlflow.runName	test-run-finish	7bd4a3ddd84d44a9b6586750ea2efde7
test	true	640a310ff98043ca8d51c9579a2caa37
environment	testing	640a310ff98043ca8d51c9579a2caa37
developer	automated-test	640a310ff98043ca8d51c9579a2caa37
mlflow.runName	test-run-artifacts	640a310ff98043ca8d51c9579a2caa37
mlflow.user	axelofwar	9987474eed4c450eb5dcd74b333f63fc
mlflow.source.name	-c	9987474eed4c450eb5dcd74b333f63fc
mlflow.source.type	LOCAL	9987474eed4c450eb5dcd74b333f63fc
test	true	9987474eed4c450eb5dcd74b333f63fc
environment	testing	9987474eed4c450eb5dcd74b333f63fc
developer	automated-test	9987474eed4c450eb5dcd74b333f63fc
mlflow.runName	nervous-ant-138	9987474eed4c450eb5dcd74b333f63fc
\.


--
-- Data for Name: trace_info; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.trace_info (request_id, experiment_id, timestamp_ms, execution_time_ms, status) FROM stdin;
\.


--
-- Data for Name: trace_request_metadata; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.trace_request_metadata (key, value, request_id) FROM stdin;
\.


--
-- Data for Name: trace_tags; Type: TABLE DATA; Schema: public; Owner: mlflow
--

COPY public.trace_tags (key, value, request_id) FROM stdin;
\.


--
-- Name: experiments_experiment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mlflow
--

SELECT pg_catalog.setval('public.experiments_experiment_id_seq', 13, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: datasets dataset_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT dataset_pk PRIMARY KEY (experiment_id, name, digest);


--
-- Name: experiments experiment_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiment_pk PRIMARY KEY (experiment_id);


--
-- Name: experiment_tags experiment_tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiment_tags
    ADD CONSTRAINT experiment_tag_pk PRIMARY KEY (key, experiment_id);


--
-- Name: experiments experiments_name_key; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_name_key UNIQUE (name);


--
-- Name: input_tags input_tags_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.input_tags
    ADD CONSTRAINT input_tags_pk PRIMARY KEY (input_uuid, name);


--
-- Name: inputs inputs_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.inputs
    ADD CONSTRAINT inputs_pk PRIMARY KEY (source_type, source_id, destination_type, destination_id);


--
-- Name: latest_metrics latest_metric_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.latest_metrics
    ADD CONSTRAINT latest_metric_pk PRIMARY KEY (key, run_uuid);


--
-- Name: metrics metric_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.metrics
    ADD CONSTRAINT metric_pk PRIMARY KEY (key, "timestamp", step, run_uuid, value, is_nan);


--
-- Name: model_versions model_version_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.model_versions
    ADD CONSTRAINT model_version_pk PRIMARY KEY (name, version);


--
-- Name: model_version_tags model_version_tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.model_version_tags
    ADD CONSTRAINT model_version_tag_pk PRIMARY KEY (key, name, version);


--
-- Name: params param_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.params
    ADD CONSTRAINT param_pk PRIMARY KEY (key, run_uuid);


--
-- Name: registered_model_aliases registered_model_alias_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_model_aliases
    ADD CONSTRAINT registered_model_alias_pk PRIMARY KEY (name, alias);


--
-- Name: registered_models registered_model_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_models
    ADD CONSTRAINT registered_model_pk PRIMARY KEY (name);


--
-- Name: registered_model_tags registered_model_tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_model_tags
    ADD CONSTRAINT registered_model_tag_pk PRIMARY KEY (key, name);


--
-- Name: runs run_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT run_pk PRIMARY KEY (run_uuid);


--
-- Name: tags tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tag_pk PRIMARY KEY (key, run_uuid);


--
-- Name: trace_info trace_info_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_info
    ADD CONSTRAINT trace_info_pk PRIMARY KEY (request_id);


--
-- Name: trace_request_metadata trace_request_metadata_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_request_metadata
    ADD CONSTRAINT trace_request_metadata_pk PRIMARY KEY (key, request_id);


--
-- Name: trace_tags trace_tag_pk; Type: CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_tags
    ADD CONSTRAINT trace_tag_pk PRIMARY KEY (key, request_id);


--
-- Name: index_datasets_dataset_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_datasets_dataset_uuid ON public.datasets USING btree (dataset_uuid);


--
-- Name: index_datasets_experiment_id_dataset_source_type; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_datasets_experiment_id_dataset_source_type ON public.datasets USING btree (experiment_id, dataset_source_type);


--
-- Name: index_inputs_destination_type_destination_id_source_type; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_inputs_destination_type_destination_id_source_type ON public.inputs USING btree (destination_type, destination_id, source_type);


--
-- Name: index_inputs_input_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_inputs_input_uuid ON public.inputs USING btree (input_uuid);


--
-- Name: index_latest_metrics_run_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_latest_metrics_run_uuid ON public.latest_metrics USING btree (run_uuid);


--
-- Name: index_metrics_run_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_metrics_run_uuid ON public.metrics USING btree (run_uuid);


--
-- Name: index_params_run_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_params_run_uuid ON public.params USING btree (run_uuid);


--
-- Name: index_tags_run_uuid; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_tags_run_uuid ON public.tags USING btree (run_uuid);


--
-- Name: index_trace_info_experiment_id_timestamp_ms; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_trace_info_experiment_id_timestamp_ms ON public.trace_info USING btree (experiment_id, timestamp_ms);


--
-- Name: index_trace_request_metadata_request_id; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_trace_request_metadata_request_id ON public.trace_request_metadata USING btree (request_id);


--
-- Name: index_trace_tags_request_id; Type: INDEX; Schema: public; Owner: mlflow
--

CREATE INDEX index_trace_tags_request_id ON public.trace_tags USING btree (request_id);


--
-- Name: datasets datasets_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(experiment_id);


--
-- Name: experiment_tags experiment_tags_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.experiment_tags
    ADD CONSTRAINT experiment_tags_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(experiment_id);


--
-- Name: trace_info fk_trace_info_experiment_id; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_info
    ADD CONSTRAINT fk_trace_info_experiment_id FOREIGN KEY (experiment_id) REFERENCES public.experiments(experiment_id);


--
-- Name: trace_request_metadata fk_trace_request_metadata_request_id; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_request_metadata
    ADD CONSTRAINT fk_trace_request_metadata_request_id FOREIGN KEY (request_id) REFERENCES public.trace_info(request_id) ON DELETE CASCADE;


--
-- Name: trace_tags fk_trace_tags_request_id; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.trace_tags
    ADD CONSTRAINT fk_trace_tags_request_id FOREIGN KEY (request_id) REFERENCES public.trace_info(request_id) ON DELETE CASCADE;


--
-- Name: latest_metrics latest_metrics_run_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.latest_metrics
    ADD CONSTRAINT latest_metrics_run_uuid_fkey FOREIGN KEY (run_uuid) REFERENCES public.runs(run_uuid);


--
-- Name: metrics metrics_run_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.metrics
    ADD CONSTRAINT metrics_run_uuid_fkey FOREIGN KEY (run_uuid) REFERENCES public.runs(run_uuid);


--
-- Name: model_version_tags model_version_tags_name_version_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.model_version_tags
    ADD CONSTRAINT model_version_tags_name_version_fkey FOREIGN KEY (name, version) REFERENCES public.model_versions(name, version) ON UPDATE CASCADE;


--
-- Name: model_versions model_versions_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.model_versions
    ADD CONSTRAINT model_versions_name_fkey FOREIGN KEY (name) REFERENCES public.registered_models(name) ON UPDATE CASCADE;


--
-- Name: params params_run_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.params
    ADD CONSTRAINT params_run_uuid_fkey FOREIGN KEY (run_uuid) REFERENCES public.runs(run_uuid);


--
-- Name: registered_model_aliases registered_model_alias_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_model_aliases
    ADD CONSTRAINT registered_model_alias_name_fkey FOREIGN KEY (name) REFERENCES public.registered_models(name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: registered_model_tags registered_model_tags_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.registered_model_tags
    ADD CONSTRAINT registered_model_tags_name_fkey FOREIGN KEY (name) REFERENCES public.registered_models(name) ON UPDATE CASCADE;


--
-- Name: runs runs_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiments(experiment_id);


--
-- Name: tags tags_run_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mlflow
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_run_uuid_fkey FOREIGN KEY (run_uuid) REFERENCES public.runs(run_uuid);


--
-- PostgreSQL database dump complete
--

\unrestrict x7C9mcqOEBkls85j85oYS3gTTKzOS00jyAlS5elsboLe7cT5ONCojzHPRczRqRX

