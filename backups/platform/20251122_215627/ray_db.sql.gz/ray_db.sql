--
-- PostgreSQL database dump
--

\restrict 5zMYhRENj3Zin8cauWaw4FNLOU71oGo7igyLleY8y3F7nCfwErMV35btjjbH4xz

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 5zMYhRENj3Zin8cauWaw4FNLOU71oGo7igyLleY8y3F7nCfwErMV35btjjbH4xz

