#!/bin/bash
# DEPRECATED: This script does not use resource management
# Use start_all_safe.sh instead for production deployments

echo "=========================================="
echo "⚠️  DEPRECATION WARNING"
echo "=========================================="
echo ""
echo "This script (start_all.sh) has been DEPRECATED."
echo ""
echo "❌ Why deprecated:"
echo "   - Does not check system resources"
echo "   - Does not apply safe CPU/memory limits"
echo "   - Can cause system instability"
echo ""
echo "✅ Use instead:"
echo "   ./start_all_safe.sh"
echo ""
echo "This script will be removed in a future version."
echo ""
echo "Continue with unsafe startup anyway? (y/N)"
read -r response

if [[ "$response" =~ ^[Yy]$ ]]; then
    echo ""
    echo "⚠️  Proceeding with unsafe startup..."
    exec ./archived/deprecated_scripts/start_all.sh
else
    echo ""
    echo "Startup cancelled. Please use: ./start_all_safe.sh"
    exit 1
fi
