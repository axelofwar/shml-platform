--
-- PostgreSQL database dump
--

\restrict As8FXlbx50o34oPhVdZhYXom108qcoNhu3kqOINvJprN1kQMTfz0FNAMKxVcT8n

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: ray_compute
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO ray_compute;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artifact_versions; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.artifact_versions (
    artifact_id integer NOT NULL,
    job_id character varying(255) NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    artifact_path text NOT NULL,
    size_bytes bigint NOT NULL,
    checksum character varying(64),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    downloaded_count integer DEFAULT 0,
    last_accessed timestamp with time zone,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.artifact_versions OWNER TO ray_compute;

--
-- Name: artifact_versions_artifact_id_seq; Type: SEQUENCE; Schema: public; Owner: ray_compute
--

CREATE SEQUENCE public.artifact_versions_artifact_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.artifact_versions_artifact_id_seq OWNER TO ray_compute;

--
-- Name: artifact_versions_artifact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ray_compute
--

ALTER SEQUENCE public.artifact_versions_artifact_id_seq OWNED BY public.artifact_versions.artifact_id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.audit_log (
    log_id integer NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(255),
    details text,
    ip_address character varying(45),
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    success boolean DEFAULT true
);


ALTER TABLE public.audit_log OWNER TO ray_compute;

--
-- Name: audit_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ray_compute
--

CREATE SEQUENCE public.audit_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_log_id_seq OWNER TO ray_compute;

--
-- Name: audit_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ray_compute
--

ALTER SEQUENCE public.audit_log_log_id_seq OWNED BY public.audit_log.log_id;


--
-- Name: job_queue; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.job_queue (
    queue_id integer NOT NULL,
    job_id character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    priority_score numeric(10,2) DEFAULT 0.00 NOT NULL,
    enqueued_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    estimated_start_time timestamp with time zone,
    position_in_queue integer
);


ALTER TABLE public.job_queue OWNER TO ray_compute;

--
-- Name: job_queue_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: ray_compute
--

CREATE SEQUENCE public.job_queue_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.job_queue_queue_id_seq OWNER TO ray_compute;

--
-- Name: job_queue_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ray_compute
--

ALTER SEQUENCE public.job_queue_queue_id_seq OWNED BY public.job_queue.queue_id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.jobs (
    job_id character varying(255) NOT NULL,
    ray_job_id character varying(255),
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    job_type character varying(50) NOT NULL,
    language character varying(50) DEFAULT 'python'::character varying NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    priority character varying(50) DEFAULT 'normal'::character varying NOT NULL,
    cpu_requested integer NOT NULL,
    memory_gb_requested integer NOT NULL,
    gpu_requested numeric(3,2) DEFAULT 0.00 NOT NULL,
    timeout_hours integer NOT NULL,
    cpu_used_hours numeric(10,2),
    gpu_used_hours numeric(10,2),
    memory_peak_gb numeric(10,2),
    disk_used_gb numeric(10,2),
    base_image character varying(255),
    dockerfile_hash character varying(64),
    custom_dockerfile boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    queued_at timestamp with time zone,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    output_mode character varying(50) DEFAULT 'artifacts'::character varying,
    artifact_path text,
    artifact_size_bytes bigint,
    artifact_retention_days integer DEFAULT 90,
    artifact_downloaded_at timestamp with time zone,
    mlflow_experiment character varying(255),
    mlflow_run_id character varying(255),
    tags text[],
    cost_center character varying(255),
    depends_on character varying(255)[],
    error_message text,
    error_traceback text,
    exit_code integer,
    retry_count integer DEFAULT 0,
    max_retries integer DEFAULT 3,
    cancelled_by uuid,
    cancelled_at timestamp with time zone,
    cancellation_reason text,
    CONSTRAINT jobs_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'normal'::character varying, 'high'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.jobs OWNER TO ray_compute;

--
-- Name: resource_usage_daily; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.resource_usage_daily (
    usage_id integer NOT NULL,
    user_id uuid NOT NULL,
    usage_date timestamp with time zone NOT NULL,
    cpu_hours numeric(10,2) DEFAULT 0.00,
    gpu_hours numeric(10,2) DEFAULT 0.00,
    storage_gb numeric(10,2) DEFAULT 0.00,
    jobs_completed integer DEFAULT 0,
    jobs_failed integer DEFAULT 0
);


ALTER TABLE public.resource_usage_daily OWNER TO ray_compute;

--
-- Name: resource_usage_daily_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: ray_compute
--

CREATE SEQUENCE public.resource_usage_daily_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resource_usage_daily_usage_id_seq OWNER TO ray_compute;

--
-- Name: resource_usage_daily_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ray_compute
--

ALTER SEQUENCE public.resource_usage_daily_usage_id_seq OWNED BY public.resource_usage_daily.usage_id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.schema_migrations (
    migration_id integer NOT NULL,
    migration_name character varying(255) NOT NULL,
    applied_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    success boolean DEFAULT true,
    error_message text
);


ALTER TABLE public.schema_migrations OWNER TO ray_compute;

--
-- Name: schema_migrations_migration_id_seq; Type: SEQUENCE; Schema: public; Owner: ray_compute
--

CREATE SEQUENCE public.schema_migrations_migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schema_migrations_migration_id_seq OWNER TO ray_compute;

--
-- Name: schema_migrations_migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ray_compute
--

ALTER SEQUENCE public.schema_migrations_migration_id_seq OWNED BY public.schema_migrations.migration_id;


--
-- Name: system_alerts; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.system_alerts (
    alert_id integer NOT NULL,
    severity character varying(50) NOT NULL,
    alert_type character varying(100) NOT NULL,
    message text NOT NULL,
    details text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    is_acknowledged boolean DEFAULT false,
    acknowledged_by uuid,
    acknowledged_at timestamp with time zone,
    CONSTRAINT system_alerts_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'error'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.system_alerts OWNER TO ray_compute;

--
-- Name: system_alerts_alert_id_seq; Type: SEQUENCE; Schema: public; Owner: ray_compute
--

CREATE SEQUENCE public.system_alerts_alert_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_alerts_alert_id_seq OWNER TO ray_compute;

--
-- Name: system_alerts_alert_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ray_compute
--

ALTER SEQUENCE public.system_alerts_alert_id_seq OWNED BY public.system_alerts.alert_id;


--
-- Name: user_quotas; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.user_quotas (
    user_id uuid NOT NULL,
    max_concurrent_jobs integer DEFAULT 3 NOT NULL,
    max_gpu_hours_per_day numeric(10,2) DEFAULT 24.0 NOT NULL,
    max_cpu_hours_per_day numeric(10,2) DEFAULT 100.0 NOT NULL,
    max_storage_gb integer DEFAULT 50 NOT NULL,
    max_artifact_size_gb integer DEFAULT 50 NOT NULL,
    max_job_timeout_hours integer DEFAULT 48 NOT NULL,
    priority_weight integer DEFAULT 1 NOT NULL,
    can_use_custom_docker boolean DEFAULT false,
    can_skip_validation boolean DEFAULT false,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_quotas OWNER TO ray_compute;

--
-- Name: users; Type: TABLE; Schema: public; Owner: ray_compute
--

CREATE TABLE public.users (
    user_id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(255),
    email character varying(255),
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    oauth_sub character varying(255),
    api_key_hash character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp with time zone,
    is_active boolean DEFAULT true,
    is_suspended boolean DEFAULT false,
    suspension_reason text,
    suspended_at timestamp with time zone,
    suspended_by uuid,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'premium'::character varying, 'user'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO ray_compute;

--
-- Name: artifact_versions artifact_id; Type: DEFAULT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.artifact_versions ALTER COLUMN artifact_id SET DEFAULT nextval('public.artifact_versions_artifact_id_seq'::regclass);


--
-- Name: audit_log log_id; Type: DEFAULT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN log_id SET DEFAULT nextval('public.audit_log_log_id_seq'::regclass);


--
-- Name: job_queue queue_id; Type: DEFAULT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.job_queue ALTER COLUMN queue_id SET DEFAULT nextval('public.job_queue_queue_id_seq'::regclass);


--
-- Name: resource_usage_daily usage_id; Type: DEFAULT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.resource_usage_daily ALTER COLUMN usage_id SET DEFAULT nextval('public.resource_usage_daily_usage_id_seq'::regclass);


--
-- Name: schema_migrations migration_id; Type: DEFAULT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.schema_migrations ALTER COLUMN migration_id SET DEFAULT nextval('public.schema_migrations_migration_id_seq'::regclass);


--
-- Name: system_alerts alert_id; Type: DEFAULT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.system_alerts ALTER COLUMN alert_id SET DEFAULT nextval('public.system_alerts_alert_id_seq'::regclass);


--
-- Data for Name: artifact_versions; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.artifact_versions (artifact_id, job_id, version, artifact_path, size_bytes, checksum, created_at, expires_at, downloaded_count, last_accessed, is_deleted) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.audit_log (log_id, user_id, action, resource_type, resource_id, details, ip_address, user_agent, "timestamp", success) FROM stdin;
\.


--
-- Data for Name: job_queue; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.job_queue (queue_id, job_id, user_id, priority_score, enqueued_at, estimated_start_time, position_in_queue) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.jobs (job_id, ray_job_id, user_id, name, description, job_type, language, status, priority, cpu_requested, memory_gb_requested, gpu_requested, timeout_hours, cpu_used_hours, gpu_used_hours, memory_peak_gb, disk_used_gb, base_image, dockerfile_hash, custom_dockerfile, created_at, queued_at, started_at, ended_at, output_mode, artifact_path, artifact_size_bytes, artifact_retention_days, artifact_downloaded_at, mlflow_experiment, mlflow_run_id, tags, cost_center, depends_on, error_message, error_traceback, exit_code, retry_count, max_retries, cancelled_by, cancelled_at, cancellation_reason) FROM stdin;
\.


--
-- Data for Name: resource_usage_daily; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.resource_usage_daily (usage_id, user_id, usage_date, cpu_hours, gpu_hours, storage_gb, jobs_completed, jobs_failed) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.schema_migrations (migration_id, migration_name, applied_at, success, error_message) FROM stdin;
1	001_initial_schema.sql	2025-11-23 14:10:21.792711+00	t	\N
\.


--
-- Data for Name: system_alerts; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.system_alerts (alert_id, severity, alert_type, message, details, created_at, resolved_at, resolved_by, is_acknowledged, acknowledged_by, acknowledged_at) FROM stdin;
\.


--
-- Data for Name: user_quotas; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.user_quotas (user_id, max_concurrent_jobs, max_gpu_hours_per_day, max_cpu_hours_per_day, max_storage_gb, max_artifact_size_gb, max_job_timeout_hours, priority_weight, can_use_custom_docker, can_skip_validation, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ray_compute
--

COPY public.users (user_id, username, email, role, oauth_sub, api_key_hash, created_at, updated_at, last_login, is_active, is_suspended, suspension_reason, suspended_at, suspended_by) FROM stdin;
70c371fd-c9d7-4e62-926e-bd4955a1c82e	admin	admin@raycompute.local	admin	\N	\N	2025-11-23 14:10:21.816564+00	2025-11-23 14:10:21.816564+00	\N	t	f	\N	\N	\N
\.


--
-- Name: artifact_versions_artifact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ray_compute
--

SELECT pg_catalog.setval('public.artifact_versions_artifact_id_seq', 1, false);


--
-- Name: audit_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ray_compute
--

SELECT pg_catalog.setval('public.audit_log_log_id_seq', 1, false);


--
-- Name: job_queue_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ray_compute
--

SELECT pg_catalog.setval('public.job_queue_queue_id_seq', 1, false);


--
-- Name: resource_usage_daily_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ray_compute
--

SELECT pg_catalog.setval('public.resource_usage_daily_usage_id_seq', 1, false);


--
-- Name: schema_migrations_migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ray_compute
--

SELECT pg_catalog.setval('public.schema_migrations_migration_id_seq', 1, true);


--
-- Name: system_alerts_alert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ray_compute
--

SELECT pg_catalog.setval('public.system_alerts_alert_id_seq', 1, false);


--
-- Name: artifact_versions artifact_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.artifact_versions
    ADD CONSTRAINT artifact_versions_pkey PRIMARY KEY (artifact_id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (log_id);


--
-- Name: job_queue job_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.job_queue
    ADD CONSTRAINT job_queue_pkey PRIMARY KEY (queue_id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (job_id);


--
-- Name: jobs jobs_ray_job_id_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_ray_job_id_key UNIQUE (ray_job_id);


--
-- Name: resource_usage_daily resource_usage_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.resource_usage_daily
    ADD CONSTRAINT resource_usage_daily_pkey PRIMARY KEY (usage_id);


--
-- Name: resource_usage_daily resource_usage_daily_user_id_usage_date_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.resource_usage_daily
    ADD CONSTRAINT resource_usage_daily_user_id_usage_date_key UNIQUE (user_id, usage_date);


--
-- Name: schema_migrations schema_migrations_migration_name_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_migration_name_key UNIQUE (migration_name);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (migration_id);


--
-- Name: system_alerts system_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_pkey PRIMARY KEY (alert_id);


--
-- Name: user_quotas user_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.user_quotas
    ADD CONSTRAINT user_quotas_pkey PRIMARY KEY (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_oauth_sub_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_oauth_sub_key UNIQUE (oauth_sub);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_artifact_versions_expires_at; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_artifact_versions_expires_at ON public.artifact_versions USING btree (expires_at);


--
-- Name: idx_artifact_versions_is_deleted; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_artifact_versions_is_deleted ON public.artifact_versions USING btree (is_deleted);


--
-- Name: idx_artifact_versions_job_id; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_artifact_versions_job_id ON public.artifact_versions USING btree (job_id);


--
-- Name: idx_audit_log_action; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_log_resource_type; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_audit_log_resource_type ON public.audit_log USING btree (resource_type);


--
-- Name: idx_audit_log_timestamp; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_audit_log_timestamp ON public.audit_log USING btree ("timestamp" DESC);


--
-- Name: idx_audit_log_user_id; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: idx_job_queue_enqueued_at; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_job_queue_enqueued_at ON public.job_queue USING btree (enqueued_at);


--
-- Name: idx_job_queue_priority_score; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_job_queue_priority_score ON public.job_queue USING btree (priority_score DESC);


--
-- Name: idx_job_queue_user_id; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_job_queue_user_id ON public.job_queue USING btree (user_id);


--
-- Name: idx_jobs_created_at; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_jobs_created_at ON public.jobs USING btree (created_at DESC);


--
-- Name: idx_jobs_mlflow_run_id; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_jobs_mlflow_run_id ON public.jobs USING btree (mlflow_run_id);


--
-- Name: idx_jobs_priority; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_jobs_priority ON public.jobs USING btree (priority);


--
-- Name: idx_jobs_ray_job_id; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_jobs_ray_job_id ON public.jobs USING btree (ray_job_id);


--
-- Name: idx_jobs_status; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_jobs_status ON public.jobs USING btree (status);


--
-- Name: idx_jobs_user_id; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_jobs_user_id ON public.jobs USING btree (user_id);


--
-- Name: idx_resource_usage_date; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_resource_usage_date ON public.resource_usage_daily USING btree (usage_date DESC);


--
-- Name: idx_resource_usage_user_date; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_resource_usage_user_date ON public.resource_usage_daily USING btree (user_id, usage_date DESC);


--
-- Name: idx_system_alerts_created_at; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_system_alerts_created_at ON public.system_alerts USING btree (created_at DESC);


--
-- Name: idx_system_alerts_resolved; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_system_alerts_resolved ON public.system_alerts USING btree (resolved_at) WHERE (resolved_at IS NULL);


--
-- Name: idx_system_alerts_severity; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_system_alerts_severity ON public.system_alerts USING btree (severity);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_oauth_sub; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_users_oauth_sub ON public.users USING btree (oauth_sub);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: ray_compute
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: user_quotas update_user_quotas_updated_at; Type: TRIGGER; Schema: public; Owner: ray_compute
--

CREATE TRIGGER update_user_quotas_updated_at BEFORE UPDATE ON public.user_quotas FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: ray_compute
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: artifact_versions artifact_versions_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.artifact_versions
    ADD CONSTRAINT artifact_versions_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(job_id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: job_queue job_queue_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.job_queue
    ADD CONSTRAINT job_queue_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(job_id) ON DELETE CASCADE;


--
-- Name: job_queue job_queue_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.job_queue
    ADD CONSTRAINT job_queue_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: jobs jobs_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.users(user_id);


--
-- Name: jobs jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: resource_usage_daily resource_usage_daily_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.resource_usage_daily
    ADD CONSTRAINT resource_usage_daily_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: system_alerts system_alerts_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(user_id);


--
-- Name: system_alerts system_alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(user_id);


--
-- Name: user_quotas user_quotas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.user_quotas
    ADD CONSTRAINT user_quotas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: users users_suspended_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ray_compute
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_suspended_by_fkey FOREIGN KEY (suspended_by) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict As8FXlbx50o34oPhVdZhYXom108qcoNhu3kqOINvJprN1kQMTfz0FNAMKxVcT8n

